import json
import random
import time

from Pyro5.api import expose, Daemon

"""
test_data:成功数据，电压位移缸
        保压时间：29s
        压力：37
        油缸长度：900
test_data_pression_result_fail:压力结果失败数据，电压位移缸
        保压时间：358s
        压力 40
        油缸长度1000
test_data_displacement_result_fail:位移结果失败数据，电压位移缸
        保压时间：358s
        压力 38
        油缸长度1000
no_displacement:无位移缸
        保压时间：29s
        压力：40
"""

# 导入原始数据
with open("no_displacement.json") as fp:
    data_list = json.load(fp)
is_test = 0
start_time = 0
data_num = len(data_list) - 1
num = None

print(len(data_list))


# 配置pyro5
@expose
class Moxa(object):
    def do_config(self, action_code, switch):
        """
        控制动作函数
        :param action_code: 动作码
        :param switch: 开关 0关 1开
        :return:
        """
        global is_test, start_time
        if is_test != 1:
            start_time = time.time()
        is_test = 1
        switch_str = ""
        action_str = ""
        if switch == 1:
            switch_str = "开"
        elif switch == 0:
            switch_str = "关"
        else:
            pass
        if action_code == 0:
            action_str = "上腔液控"
        elif action_code == 1:
            action_str = "下腔液控"
        elif action_code == 2:
            action_str = "上腔锁"
        elif action_code == 3:
            action_str = "下腔锁"
        elif action_code == 4:
            action_str = "充液"
        elif action_code == 5:
            action_str = "卸载"
        elif action_code == 6:
            action_str = "增压1"
        elif action_code == 7:
            action_str = "增压2"
        elif action_code == 8:
            action_str = "减速"
        else:
            pass
        print(action_str + switch_str)

    def ai_data (self, data_type, data_code):
        """
        获取数据函数
        :param data_type: 1为电压 2为电流
        :param data_code: 传感器数据码
        :return: 对应数据
        """
        global num
        data = None
        num = int((time.time() - start_time) // 1.5)
        if num > data_num:
            num = data_num
        data_single_list = data_list[num]
        if data_type == 1:
            if data_code == -1:
                data = data_single_list[0]
            elif data_code == 0:
                data = data_single_list[1]
            elif data_code == 1:
                data = data_single_list[2]
            elif data_code == 2:
                data = data_single_list[1]
            elif data_code == 3:
                data = data_single_list[2]
            elif data_code == 4:
                data = data_single_list[1]
            elif data_code == 5:
                data = data_single_list[2]
            elif data_code == 6:
                data = data_single_list[1]
            elif data_code == 7:
                data = data_single_list[2]
            elif data_code == 8:
                data = 0
            elif data_code == 9:
                data = 40
            else:
                data = data_single_list[0]
        elif data_type == 2:
            print("测试不支持电流")
        else:
            pass
        if is_test == 0:
            data = random.randint(0, 100)
        #print('data++++++',data)
        return data

    def di_switching_value(self, switch_code):
        """
        开关量接受
        :param switch_code: 开关code
        :return: 对应开关量 1为开启 0为关闭
        """
        code = 0
        if switch_code == 0:
            code = 0
        elif switch_code == 1:
            code = 0
        else:
            pass
        # if num == 10:
        #     code = 1
        return code


# 初始化pyro并启动服务
with Daemon(port=7777, host="0.0.0.0") as daemon:
    uri = daemon.register(Moxa, objectId="pyro.moxa")
    print("Server started, uri: %s" % uri)
    daemon.requestLoop()
