import json
import time

with open("test_data.json", "r") as fp:
    dict1 = json.load(fp)

new_data = []
for i in dict1:
    new_data.append([i[0], (i[1] - 0.5) * 15, (i[2] - 0.5) * 15])

print(new_data)
