import threading
from apscheduler.schedulers.blocking import BlockingScheduler
from flow import *


class Schedule(object):
    @classmethod
    def ping(cls):
        """
        ping心跳任务
        """
        data={"macAddress": mac_list}
        # requests.post("http://" + url + ":" + port + "/cylinder/api/v1/deviceInfo/ping",
        #                headers = {'Content-Type': 'application/json'},data = json.dumps(data))

        # requests.post("http://cylinder.biz.ingress.zmjemc.xyz"+ "/cylinder/api/v1/deviceInfo/ping",
        #                headers = {'Content-Type': 'application/json'},data = json.dumps(data))

        requests.post("https://router-test.zmjkf.cn/api/cylinder" + "/cylinder/api/v1/deviceInfo/ping",
                      headers={'Content-Type': 'application/json'}, data=json.dumps(data))
    def start(self):
        scheduler = BlockingScheduler()
        scheduler.add_job(self.ping, 'interval', minutes=5)
        scheduler.add_job(Flow.set_queue, 'interval', seconds=1.5)
        scheduler.start()

    def run(self):
        threading.Thread(target=self.start).start()
