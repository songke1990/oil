from multiprocessing import Queue
from threading import Thread

from communication import *
from remote import *
from pi_logging import logger
from config.config import *
"""
    变化值
"""
# 油缸长度
oil_length = 0
# 压力快速增压时间间隔
fast_pressurize_time_interval = 0.5
# 压力慢速增压时间间隔
slow_pressurize_time_interval = 0.2
# 队列
q = Queue()

# 状态码
code1 = code2 = code3 = code4 = None
# 状态说明
message1 = message2 = message3 = message4 = ""
# 远程状态码
remote_code1 = remote_code2 = remote_code3 = remote_code4 = 0
# 远程说明
remote_message1 = remote_message2 = remote_message3 = remote_message4 = ""

# 缸位编号0：无缸测试，1：有缸测试
one = 0
two = 0
three = 0
four = 0

# 是否实验中
is_test = 0
pre_dict = {}

# 整个实验压力表格数据
pre_list_1 = []
pre_list_2 = []
pre_list_3 = []
pre_list_4 = []
# 是否带位移
displacement_exist = 0
# 实验类型1：电压2：电流
test_type = 1

# 实验过程中所有折线图数据list
data_list_1 = []
data_list_2 = []
data_list_3 = []
data_list_4 = []

# 放入队列json格式
queue_dict = {}
# 数据字典
data_dict = {}
# 时间
num = 0
# 远程数据参数
remote_dict = {}
# 实验唯一值
test_num = ""
# 油缸类型
oil_cylinder_type = 0

# 配置文件
displacement_offset = 0
depressurization_scope = 0
journey_time = 0
pressure_time = 0
pressure_keep = 0
stretched_num = 0
pressure_middle = 0


def get_config():
    global displacement_offset, depressurization_scope, journey_time, pressure_time, pressure_keep, stretched_num, \
        pressure_middle
    config = Config()
    displacement_offset, depressurization_scope, journey_time, pressure_time, pressure_keep, stretched_num, \
        pressure_middle = config.get_conf()
    return displacement_offset, depressurization_scope, journey_time, pressure_time, pressure_keep, stretched_num, \
        pressure_middle


get_config()


class Flow(object):

    def __init__(self, param_data):
        self.param_data = param_data
        self.pyro_object = None
        logger.info("前端入参{}：：：：：：：：：".format(param_data))

    @classmethod
    def data_convert(cls, data_type, data):  # 传感器数据转换
        """
        传感器数据转换
        :param data_type: 0:压力 1:电压位移 2:电流位移
        :param data: 原始传感器数据
        :return: 转换后数据
        """
        data = float(data)
        if oil_length == 0:
            oil_length_fun = 960
        else:
            oil_length_fun = oil_length
        if data_type == 0:
            data = (data - 0.5) * 15
        elif data_type == 1:
            data = (data - 0.5) * (oil_length_fun / 4)
        elif data_type == 2:
            data = (data - 4) * (oil_length_fun / 16)
        else:
            pass
        return data

    @classmethod
    def supercharged_dormancy_strategy(cls, mode, a, pression, t):  # 增压策略
        """
        增压休眠策略
        :param mode: 0上腔压1下腔压
        :param a: 压力最高值
        :param pression: 当前压力
        :param t: 当前时间
        :return:
        """
        if mode == 1:
            if a - pression < down_pre_diff:
                time.sleep(slow_pressurize_time_interval)
                t += slow_pressurize_time_interval
            else:
                time.sleep(fast_pressurize_time_interval)
                t += fast_pressurize_time_interval
        else:
            if a - pression < up_pre_diff:
                time.sleep(slow_pressurize_time_interval)
                t += slow_pressurize_time_interval
            else:
                time.sleep(fast_pressurize_time_interval)
                t += fast_pressurize_time_interval
        return t

    def pression_time(self, a, mode, t=0):  # 压力超时判断函数
        """
        压力时间判断函数，判断是否在时间内压力变成正确范围或时间超时
        :param a: 压力范围
        :param mode: 0 上腔压力 其他为下腔压力
        :param t: 时间控制
        :return:
        """
        pre_num = 0
        pre_index = [one, two, three, four].index(1)
        up = [up1, up2, up3, up4][pre_index]
        dp = [dp1, dp2, dp3, dp4][pre_index]
        while t <= pression_judgment_time:
            if not is_test:
                # myapp.error("检测stop为true停止实验")
                return "stop"
            # 压力数据
            if mode == 0:
                pression1 = self.data_convert(0, Communication.data(1, up1, self.pyro_object))
                pression2 = self.data_convert(0, Communication.data(1, up2, self.pyro_object))
                pression3 = self.data_convert(0, Communication.data(1, up3, self.pyro_object))
                pression4 = self.data_convert(0, Communication.data(1, up4, self.pyro_object))
                pression = self.data_convert(0, Communication.data(1, up, self.pyro_object))
            else:
                pression1 = self.data_convert(0, Communication.data(1, dp1, self.pyro_object))
                pression2 = self.data_convert(0, Communication.data(1, dp2, self.pyro_object))
                pression3 = self.data_convert(0, Communication.data(1, dp3, self.pyro_object))
                pression4 = self.data_convert(0, Communication.data(1, dp4, self.pyro_object))
                pression = self.data_convert(0, Communication.data(1, dp, self.pyro_object))

            if (pression1 > pre_max) or (pression2 > pre_max) or (pression3 > pre_max) or (pression4 > pre_max):
                return "error"

            if (not one or (pression1 > a)) and (not two or (pression2 > a)) and (not three or (pression3 > a)) and (
                    not four or (pression4 > a)):
                break
            else:
                if pre_num % 2 == 0:
                    Communication.action(6, 1, self.pyro_object)  # 加压1开启
                    t = self.supercharged_dormancy_strategy(mode, a, pression, t)
                    Communication.action(6, 0, self.pyro_object)  # 加压1关闭
                    time.sleep(0.3)
                    t += 0.3
                else:
                    Communication.action(7, 1, self.pyro_object)  # 加压2开启
                    t = self.supercharged_dormancy_strategy(mode, a, pression, t)
                    Communication.action(7, 0, self.pyro_object)  # 加压2关闭
                    time.sleep(0.3)
                    t += 0.3
                if mode == 0:
                    pre_diff = self.data_convert(0, Communication.data(1, up, self.pyro_object)) - pression
                else:
                    pre_diff = self.data_convert(0, Communication.data(1, dp, self.pyro_object)) - pression
                # 增压压力小于1
                if pre_diff < add_pre_diff:
                    pre_num += 1
            time.sleep(0.05)
            t += 0.05
        if t > pression_judgment_time:
            return True
        else:
            return False

    def pression_law(self, t2, mode, table_str, t=0):  # 保压函数
        """
        保压
        :param t2: 保压稳态时长
        :param mode: 0 上腔压 其他下腔
        :param table_str: 当前保压阶段说明
        :param t: 时间控制
        :return:
        """
        global pre_dict
        pression1_max_min = []
        pression2_max_min = []
        pression3_max_min = []
        pression4_max_min = []

        pre_diff_first_bool1 = True
        pre_diff_first_bool2 = True
        pre_diff_first_bool3 = True
        pre_diff_first_bool4 = True

        diff1 = [0, 0, 0, 0]

        while True:
            if not is_test:
                return "stop"
            if mode == 0:
                pression1 = self.data_convert(0, Communication.data(1, up1, self.pyro_object))
                pression2 = self.data_convert(0, Communication.data(1, up2, self.pyro_object))
                pression3 = self.data_convert(0, Communication.data(1, up3, self.pyro_object))
                pression4 = self.data_convert(0, Communication.data(1, up4, self.pyro_object))
            else:
                pression1 = self.data_convert(0, Communication.data(1, dp1, self.pyro_object))
                pression2 = self.data_convert(0, Communication.data(1, dp2, self.pyro_object))
                pression3 = self.data_convert(0, Communication.data(1, dp3, self.pyro_object))
                pression4 = self.data_convert(0, Communication.data(1, dp4, self.pyro_object))

            if t > 2:
                pression1_max_min.append(pression1)
                pression2_max_min.append(pression2)
                pression3_max_min.append(pression3)
                pression4_max_min.append(pression4)

                if t == 60:
                    pression1_max_min.sort()
                    pression2_max_min.sort()
                    pression3_max_min.sort()
                    pression4_max_min.sort()

                    pre_diff_first1 = pression1_max_min[-1] - pression1_max_min[0]
                    pre_diff_first2 = pression2_max_min[-1] - pression2_max_min[0]
                    pre_diff_first3 = pression3_max_min[-1] - pression3_max_min[0]
                    pre_diff_first4 = pression4_max_min[-1] - pression4_max_min[0]

                    pre_diff_first_bool1 = pre_diff_first1 < pressure_keep * 0.1
                    pre_diff_first_bool2 = pre_diff_first2 < pressure_keep * 0.1
                    pre_diff_first_bool3 = pre_diff_first3 < pressure_keep * 0.1
                    pre_diff_first_bool4 = pre_diff_first4 < pressure_keep * 0.1

                    diff1 = [round(pre_diff_first1, 2),
                             round(pre_diff_first2, 2),
                             round(pre_diff_first3, 2),
                             round(pre_diff_first4, 2)]
                    pression1_max_min.clear()
                    pression2_max_min.clear()
                    pression3_max_min.clear()
                    pression4_max_min.clear()
            time.sleep(0.5)
            t += 0.5
            if t > t2:
                pression1_max_min.sort()
                pression2_max_min.sort()
                pression3_max_min.sort()
                pression4_max_min.sort()
                pre_diff_second1 = pression1_max_min[-1] - pression1_max_min[0]
                pre_diff_second2 = pression2_max_min[-1] - pression2_max_min[0]
                pre_diff_second3 = pression3_max_min[-1] - pression3_max_min[0]
                pre_diff_second4 = pression4_max_min[-1] - pression4_max_min[0]

                pre_diff_second_bool1 = pre_diff_second1 < depressurization_scope
                pre_diff_second_bool2 = pre_diff_second2 < depressurization_scope
                pre_diff_second_bool3 = pre_diff_second3 < depressurization_scope
                pre_diff_second_bool4 = pre_diff_second4 < depressurization_scope

                p_max_min = [round(pression1_max_min[-1], 2),
                             round(pression2_max_min[-1], 2),
                             round(pression3_max_min[-1], 2),
                             round(pression4_max_min[-1], 2)]

                diff2 = [round(pre_diff_second1, 2),
                         round(pre_diff_second2, 2),
                         round(pre_diff_second3, 2),
                         round(pre_diff_second4, 2)]

                pre_bool = [pre_diff_second_bool1 and pre_diff_first_bool1,
                            pre_diff_second_bool2 and pre_diff_first_bool2,
                            pre_diff_second_bool3 and pre_diff_first_bool3,
                            pre_diff_second_bool4 and pre_diff_first_bool4]

                pre_list_1.append({"preInfo": table_str,
                                   "preValue": p_max_min[0],
                                   "preTime": t2,
                                   "preDropFirst": diff1[0],
                                   "preDrop": diff2[0],
                                   "boolValue": pre_bool[0]})

                pre_list_2.append({"preInfo": table_str,
                                   "preValue": p_max_min[1],
                                   "preTime": t2,
                                   "preDropFirst": diff1[1],
                                   "preDrop": diff2[1],
                                   "boolValue": pre_bool[1]})

                pre_list_3.append({"preInfo": table_str,
                                   "preValue": p_max_min[2],
                                   "preTime": t2,
                                   "preDropFirst": diff1[2],
                                   "preDrop": diff2[2],
                                   "boolValue": pre_bool[2]})

                pre_list_4.append({"preInfo": table_str,
                                   "preValue": p_max_min[3],
                                   "preTime": t2,
                                   "preDropFirst": diff1[3],
                                   "preDrop": diff2[3],
                                   "boolValue": pre_bool[3]})

                pre_dict = {"pre_info": table_str,
                            "pre_value": p_max_min,
                            "pre_time": t2,
                            "pre_drop_first": diff1,
                            "pre_drop": diff2,
                            "bool_value": pre_bool}
                return diff2

    def no_displacement_judge(self, mode, t=0):
        """
        无位移缸判断位移
        :param mode: 0上腔压1下腔压
        :param t:
        :return:
        """
        n = 0
        while t <= displacement_judgment_time:
            if not is_test:
                return "stop"
            if mode == 0:
                pression1 = self.data_convert(0, Communication.data(1, up1, self.pyro_object))
                pression2 = self.data_convert(0, Communication.data(1, up2, self.pyro_object))
                pression3 = self.data_convert(0, Communication.data(1, up3, self.pyro_object))
                pression4 = self.data_convert(0, Communication.data(1, up4, self.pyro_object))

            else:
                pression1 = self.data_convert(0, Communication.data(1, dp1, self.pyro_object))
                pression2 = self.data_convert(0, Communication.data(1, dp2, self.pyro_object))
                pression3 = self.data_convert(0, Communication.data(1, dp3, self.pyro_object))
                pression4 = self.data_convert(0, Communication.data(1, dp4, self.pyro_object))
            system_pre = self.data_convert(0, Communication.data(1, sp, self.pyro_object))

            if (not one or (system_pre - pression1 < system_pre_diff_abs)) and \
                    (not two or (system_pre - pression2 < system_pre_diff_abs)) and \
                    (not three or (system_pre - pression3 < system_pre_diff_abs)) and \
                    (not four or (system_pre - pression4 < system_pre_diff_abs)):
                n += 1
            else:
                n = 0
            if n >= system_pre_diff_num:
                break
            time.sleep(0.05)
            t += 0.05
        if t > displacement_judgment_time:
            return True
        else:
            return False

    def init_check(self):
        """
        校验初始化是否成功
        :return:
        """
        up_pre1 = self.data_convert(0, Communication.data(1, up1, self.pyro_object))
        up_pre2 = self.data_convert(0, Communication.data(1, up2, self.pyro_object))
        up_pre3 = self.data_convert(0, Communication.data(1, up3, self.pyro_object))
        up_pre4 = self.data_convert(0, Communication.data(1, up4, self.pyro_object))

        down_pre1 = self.data_convert(0, Communication.data(1, dp1, self.pyro_object))
        down_pre2 = self.data_convert(0, Communication.data(1, dp2, self.pyro_object))
        down_pre3 = self.data_convert(0, Communication.data(1, dp3, self.pyro_object))
        down_pre4 = self.data_convert(0, Communication.data(1, dp4, self.pyro_object))
        if (not one or (up_pre1 > 5 or down_pre1 > 5)) or \
                (not two or (up_pre2 > 5 or down_pre2 > 5)) or \
                (not three or (up_pre3 > 5 or down_pre3 > 5)) or \
                (not four or (up_pre4 > 5 or down_pre4 > 5)):
            self.stop_init()
            up_pre1 = self.data_convert(0, Communication.data(1, up1, self.pyro_object))
            up_pre2 = self.data_convert(0, Communication.data(1, up2, self.pyro_object))
            up_pre3 = self.data_convert(0, Communication.data(1, up3, self.pyro_object))
            up_pre4 = self.data_convert(0, Communication.data(1, up4, self.pyro_object))

            down_pre1 = self.data_convert(0, Communication.data(1, dp1, self.pyro_object))
            down_pre2 = self.data_convert(0, Communication.data(1, dp2, self.pyro_object))
            down_pre3 = self.data_convert(0, Communication.data(1, dp3, self.pyro_object))
            down_pre4 = self.data_convert(0, Communication.data(1, dp4, self.pyro_object))
            if (not one or (up_pre1 > 5 or down_pre1 > 5)) or \
                    (not two or (up_pre2 > 5 or down_pre2 > 5)) or \
                    (not three or (up_pre3 > 5 or down_pre3 > 5)) or \
                    (not four or (up_pre4 > 5 or down_pre4 > 5)):
                return True
        return False

    def stop_init(self):
        """
        全部关闭
        Communication().action(动作码, 开关)
        关 0开 1关
        :return:
        """
        Communication.action(0, 0, self.pyro_object)  # 上腔停液
        Communication.action(1, 0, self.pyro_object)  # 下腔停液
        Communication.action(2, 0, self.pyro_object)  # 上腔锁关闭
        Communication.action(3, 0, self.pyro_object)  # 下腔锁关闭
        Communication.action(4, 0, self.pyro_object)  # 充液
        Communication.action(5, 0, self.pyro_object)  # 卸载
        Communication.action(6, 0, self.pyro_object)  # 加压1
        Communication.action(7, 0, self.pyro_object)  # 加压2
        Communication.action(8, 0, self.pyro_object)  # 减速

        # 泄压
        Communication.action(2, 1, self.pyro_object)  # 上腔锁打开
        Communication.action(3, 1, self.pyro_object)  # 下腔锁打开
        Communication.action(5, 1, self.pyro_object)  # 卸载打开

        time.sleep(3)

        Communication.action(2, 0, self.pyro_object)  # 上腔锁打开
        Communication.action(3, 0, self.pyro_object)  # 下腔锁打开
        Communication.action(5, 0, self.pyro_object)  # 卸载打开

    def data_transmission(self):
        """
        远程数据传输
        :return:
        """
        list1 = [one, two, three, four]
        all_pre = [pre_list_1, pre_list_2, pre_list_3, pre_list_4]
        all_data = [data_list_1, data_list_2, data_list_3, data_list_4]
        for i in range(len(list1)):
            if list1[i]:
                logger.error("{}号油缸远程数据传输ing：：：：：：：：".format((i + 1)))
                remote_dict["user_no"] = self.param_data["user_no"]
                remote_dict["construction_no"] = self.param_data["construction_no"]
                remote_dict["product_no"] = self.param_data["product_no"][i]
                remote_dict["code"] = [remote_code1, remote_code2, remote_code3, remote_code4][i]
                remote_dict["message"] = [remote_message1, remote_message2, remote_message3, remote_message4][i]
                remote_dict["data"] = {"num": test_num + str(i),
                                       "dataList": all_data[i],
                                       "preList": all_pre[i]}
                remote_dict["oil_cylinder_type"] = self.param_data["oil_cylinder_type"]
                logger.info("{num}号油缸远程数据参数{data}：：：：：：：：".format(num=(i + 1), data=remote_dict))
                remote = Remote(json.dumps(remote_dict))
                remote.transmit_data()

    def stop_operate(self):
        """
        急停情况操作
        :return:
        """
        global code1, code2, code3, code4, \
            message1, message2, message3, message4, \
            remote_code1, remote_code2, remote_code3, remote_code4, \
            remote_message1, remote_message2, remote_message3, remote_message4, is_test
        self.stop_init()
        code1 = code2 = code3 = code4 = remote_code1 = remote_code2 = remote_code3 = remote_code4 = 2
        message1 = message2 = message3 = message4 = remote_message1 = remote_message2 = remote_message3 \
            = remote_message4 = "停止实验"
        is_test = 0
        self.data_transmission()

    def error_operate(self, error_code, error_message):
        """
        错误情况操作
        :param error_code: 错误代码
        :param error_message: 错误信息
        :return:
        """
        global code1, code2, code3, code4, \
            message1, message2, message3, message4, \
            remote_code1, remote_code2, remote_code3, remote_code4, \
            remote_message1, remote_message2, remote_message3, remote_message4, is_test
        if not is_test:
            self.stop_operate()
            return
        self.stop_init()
        remote_code1 = remote_code2 = remote_code3 = remote_code4 = error_code
        remote_message1 = remote_message2 = remote_message3 = remote_message4 = error_message
        if self.init_check():
            message1 = remote_message1 + "请手动泄压"
            message2 = remote_message2 + "请手动泄压"
            message3 = remote_message3 + "请手动泄压"
            message4 = remote_message4 + "请手动泄压"
        else:
            message1 = remote_message1
            message2 = remote_message2
            message3 = remote_message3
            message4 = remote_message4
        code1 = remote_code1
        code2 = remote_code2
        code3 = remote_code3
        code4 = remote_code4
        is_test = 0
        self.data_transmission()

    def oil_cylinder_extend(self, is_extend):
        """
        油缸伸出
        :param is_extend: 0停止1伸出
        :return:
        """
        if is_extend:
            Communication.action(2, 1, self.pyro_object)  # 上腔锁打开
            time.sleep(0.5)
            Communication.action(1, 1, self.pyro_object)  # 下腔进液
            Communication.action(4, 1, self.pyro_object)  # 充液
        else:
            Communication.action(1, 0, self.pyro_object)  # 下腔停液
            Communication.action(2, 0, self.pyro_object)  # 上腔锁关闭
            Communication.action(4, 0, self.pyro_object)  # 充液停止

    def oil_cylinder_recover(self, is_recover):
        """
        油缸收回
        :param is_recover:
        :return:
        """
        if is_recover:
            Communication.action(3, 1, self.pyro_object)  # 下腔锁打开
            time.sleep(0.5)
            Communication.action(0, 1, self.pyro_object)  # 上腔给液
            Communication.action(4, 1, self.pyro_object)  # 充液
        else:
            Communication.action(0, 0, self.pyro_object)  # 上腔停液
            Communication.action(3, 0, self.pyro_object)  # 下腔锁关闭
            Communication.action(4, 0, self.pyro_object)  # 充液关闭

    @classmethod
    def table_result_check(cls):
        global remote_code1, remote_code2, remote_code3, remote_code4, \
            remote_message1, remote_message2, remote_message3, remote_message4

        remote_code1 = remote_code2 = remote_code3 = remote_code4 = 1
        remote_message1 = remote_message2 = remote_message3 = remote_message4 = "试验成功"

        pre_bool_list1 = [pre_list_1[0]["boolValue"], pre_list_2[0]["boolValue"], pre_list_3[0]["boolValue"],
                          pre_list_4[0]["boolValue"]]
        for i in range(len(pre_bool_list1)):
            if i == 0:
                if not pre_bool_list1[i]:
                    remote_code1 = 10
                    remote_message1 = "保压异常"
            if i == 1:
                if not pre_bool_list1[i]:
                    remote_code2 = 10
                    remote_message2 = "保压异常"
            if i == 2:
                if not pre_bool_list1[i]:
                    remote_code3 = 10
                    remote_message3 = "保压异常"
            if i == 3:
                if not pre_bool_list1[i]:
                    remote_code4 = 10
                    remote_message4 = "保压异常"

        pre_bool_list2 = [pre_list_1[1]["boolValue"], pre_list_2[1]["boolValue"], pre_list_3[1]["boolValue"],
                          pre_list_4[1]["boolValue"]]
        for i in range(len(pre_bool_list2)):
            if i == 0:
                if not pre_bool_list2[i]:
                    remote_code1 = 10
                    remote_message1 = "保压异常"
            if i == 1:
                if not pre_bool_list2[i]:
                    remote_code2 = 10
                    remote_message2 = "保压异常"
            if i == 2:
                if not pre_bool_list2[i]:
                    remote_code3 = 10
                    remote_message3 = "保压异常"
            if i == 3:
                if not pre_bool_list2[i]:
                    remote_code4 = 10
                    remote_message4 = "保压异常"

    def pressurization_protection(self, mode):
        """
        保压保护
        :param mode: 0上腔压 1下腔压
        :return:
        """
        if mode == 1:
            Communication.action(3, 1, self.pyro_object)
        else:
            Communication.action(2, 1, self.pyro_object)
        for i in range(3):
            time.sleep(2)
            if mode == 0:
                pression1 = self.data_convert(0, Communication.data(1, up1, self.pyro_object))
                pression2 = self.data_convert(0, Communication.data(1, up2, self.pyro_object))
                pression3 = self.data_convert(0, Communication.data(1, up3, self.pyro_object))
                pression4 = self.data_convert(0, Communication.data(1, up4, self.pyro_object))
            else:
                pression1 = self.data_convert(0, Communication.data(1, dp1, self.pyro_object))
                pression2 = self.data_convert(0, Communication.data(1, dp2, self.pyro_object))
                pression3 = self.data_convert(0, Communication.data(1, dp3, self.pyro_object))
                pression4 = self.data_convert(0, Communication.data(1, dp4, self.pyro_object))
            if (not one or (pression1 < 10)) and (not two or (pression2 < 10)) and (not three or (pression3 < 10)) and (
                    not four or (pression4 < 10)):
                return False
        return True

    def no_displacement_pression_judge(self, mode):
        """
        无位移，增压超时
        mode: 0 上腔，1 下腔
        """
        Communication.action(8, 1, self.pyro_object)  # 减速打开
        # 判断下腔压力是否大于40Mpa
        pressure_return = self.pression_time(pressure_keep, mode)
        if pressure_return:
            if pressure_return == "error":
                self.error_operate(15, "压力超过最大值")
            else:
                self.error_operate(5, "增压超时")
            return True
        # 伸出停止
        self.oil_cylinder_extend(0)
        Communication.action(6, 0, self.pyro_object)  # 加压1停止
        Communication.action(7, 0, self.pyro_object)  # 加压2停止
        Communication.action(8, 0, self.pyro_object)  # 减速停止
        #卸载系统压
        Communication.action(5, 1, self.pyro_object)  # 卸载
        time.sleep(1)
        Communication.action(5, 0, self.pyro_object)
        return False

    def no_displacement_test(self):
        """
        无位移测试逻辑
        :return:
        """
        logger.info("无位移测试逻辑进入：：：：：：：：")
        global code1, code2, code3, code4, \
            message1, message2, message3, message4, \
            remote_code1, remote_code2, remote_code3, remote_code4, \
            remote_message1, remote_message2, remote_message3, remote_message4, is_test, oil_length
        # 伸出
        self.pyro_object = Pyro5.api.Proxy(pyro5_ip)
        self.oil_cylinder_extend(1)
        time.sleep(2)
        # 下强压 系统压 临界值
        if self.no_displacement_judge(1):
            self.error_operate(4, "伸出超时")
            return
        # 停止伸出
        self.oil_cylinder_extend(0)
        # 收回
        self.oil_cylinder_recover(1)
        time.sleep(2)
        if self.no_displacement_judge(0):
            self.error_operate(6, "收回超时")
            return
        # 停止收回
        self.oil_cylinder_recover(0)
        time.sleep(1)
        # 伸出
        self.oil_cylinder_extend(1)
        time.sleep(2)
        if self.no_displacement_judge(1):
            self.error_operate(4, "伸出超时")
            return
        # 减速 下腔压 判断
        if self.no_displacement_pression_judge(1):
            return
        q1 = self.pression_law(pressure_time, 1, str3)
        if q1 == "stop":
            self.stop_operate()
            return
        if self.pressurization_protection(1):
            self.error_operate(14, "高压未卸载")
            return ""
        # 控制千斤顶收回
        self.oil_cylinder_recover(1)
        time.sleep(2)
        if self.no_displacement_judge(0):
            self.error_operate(6, "收回超时")
            return
        # 减速 上腔压 判断
        if self.no_displacement_pression_judge(0):
            return
        q3 = self.pression_law(pressure_time, 0, str1)
        if q3 == "stop":
            self.stop_operate()
            return
        self.stop_init()
        self.table_result_check()
        if self.init_check():
            code1 = code2 = code3 = code4 = 12
            message1 = remote_message1 + "请手动泄压"
            message2 = remote_message2 + "请手动泄压"
            message3 = remote_message3 + "请手动泄压"
            message4 = remote_message4 + "请手动泄压"
        else:
            code1 = code2 = code3 = code4 = 1
            message1 = remote_message1
            message2 = remote_message2
            message3 = remote_message3
            message4 = remote_message4
        is_test = 0
        oil_length = 0
        self.data_transmission()

    def oil_start_init(self):
        """
        开始实验，初始化
        :return:
        """
        logger.info("初始化参数：：：：：：：：")
        global test_type, displacement_exist, oil_length, is_test, fast_pressurize_time_interval, \
            slow_pressurize_time_interval, test_num, num, oil_cylinder_type, one, two, three, four
        oil_cylinder_type = int(self.param_data["oil_cylinder_type"])

        # TODO 获取油缸位置

        one = self.param_data["oil_one"]
        two = self.param_data["oil_two"]
        three = self.param_data["oil_three"]
        four = self.param_data["oil_four"]

        if oil_cylinder_type > 5:
            fast_pressurize_time_interval = oil_size["oil_small"]["fast_interval"]
            slow_pressurize_time_interval = oil_size["oil_small"]["slow_interval"]
        else:
            fast_pressurize_time_interval = oil_size["oil_large"]["fast_interval"]
            slow_pressurize_time_interval = oil_size["oil_large"]["slow_interval"]

        if oil_cylinder_type == 1:
            oil_length = int(self.param_data["oilcylinder_length"])
            test_type = int(self.param_data["test_type"])
        else:
            oil_length = int(self.param_data["oilcylinder_length"])
            # 无位移
            displacement_exist = 0
            test_type = 1
        test_num = str(time.time())
        is_test = 1
        num = 0
        pre_dict.clear()

        pre_list_1.clear()
        pre_list_2.clear()
        pre_list_3.clear()
        pre_list_4.clear()

        data_list_1.clear()
        data_list_2.clear()
        data_list_3.clear()
        data_list_4.clear()

        queue_dict.clear()
        data_dict.clear()
        remote_dict.clear()
        logger.info("初始化参数完成：：：：：：：：")
        logger.info("油缸类型{}：：：：：：：：".format(oil_cylinder_type))

    @classmethod
    def return_message(cls, exception_code, exception_message, status):
        """
        返回报文
        :param exception_code: 异常code
        :param exception_message: 异常信息
        :param status: 返回状态
        :return:
        """
        return json.dumps({"code": exception_code, "message": exception_message, "success": status})

    def no_displacement_start(self):
        logger.info("无位移实验接口调用：：：：：：：：")
        Thread(target=self.no_displacement_start_thread).start()
        return True

    def no_displacement_start_thread(self):
        """
        无位移
        :return:
        """
        global is_test
        self.oil_start_init()
        try:
            self.no_displacement_test()
        except ConnectionFailException as e:
            is_test = 0
            q.put(self.return_message(13, str(e), False))
            logger.error("连接异常：：：：：：：：")
        else:
            self.return_message(None, None, True)

    @classmethod
    def set_queue(cls):
        try:
            cls.set_queue_job()
        except ConnectionFailException as e:
            q.put(cls.return_message(13, str(e), False))
            logger.error("连接异常：：：：：：：：")

    @classmethod
    def set_queue_job(cls):
        """
        通信数据放入队列任务
        :return:
        """
        global num, code1, code2, code3, code4, \
            message1, message2, message3, message4, is_test
        pyro = Pyro5.api.Proxy(pyro5_ip)
        if not is_test:
            num = 0
        if int(Communication.switching_value(1, pyro)) or int(Communication.switching_value(0, pyro)):
            is_test = 0
        queue_dict["isTest"] = is_test
        queue_dict["code"] = [code1, code2, code3, code4]
        queue_dict["message"] = [message1, message2, message3, message4]
        queue_dict["status"] = Communication.switching_value(1, pyro)
        queue_dict["urgent_stop"] = Communication.switching_value(0, pyro)
        data_dict["preDict"] = pre_dict
        data_dict["dataList"] = {
            'upPre': [round(cls.data_convert(0, Communication.data(1, up1, pyro)), 2),
                      round(cls.data_convert(0, Communication.data(1, up2, pyro)), 2),
                      round(cls.data_convert(0, Communication.data(1, up3, pyro)), 2),
                      round(cls.data_convert(0, Communication.data(1, up4, pyro)), 2)],

            'downPre': [round(cls.data_convert(0, Communication.data(1, dp1, pyro)), 2),
                        round(cls.data_convert(0, Communication.data(1, dp2, pyro)), 2),
                        round(cls.data_convert(0, Communication.data(1, dp3, pyro)), 2),
                        round(cls.data_convert(0, Communication.data(1, dp4, pyro)), 2)],

            'systemPre': round(cls.data_convert(0, Communication.data(1, sp, pyro)), 2),
            'pumpPre': round(cls.data_convert(0, Communication.data(1, pp, pyro)), 2),
            'currentTime': num}
        queue_dict["testNo"] = [test_num+str(i) for i in range(4)]
        queue_dict["data"] = data_dict
        q.put(json.dumps(queue_dict))
        if pre_dict:
            pre_dict.clear()
        if code1 is not None:
            logger.info("实验结果信息为code={}，message={}".format(code1, message1))
            code1 = None
            message1 = None
        if code2 is not None:
            logger.info("实验结果信息为code={}，message={}".format(code2, message2))
            code2 = None
            message2 = None
        if code3 is not None:
            logger.info("实验结果信息为code={}，message={}".format(code3, message3))
            code3 = None
            message3 = None
        if code4 is not None:
            logger.info("实验结果信息为code={}，message={}".format(code4, message4))
            code4 = None
            message4 = None
        if is_test:
            data_list_1.append(
                {'upPre': cls.data_convert(0, Communication.data(1, up1, pyro)),
                 'downPre': cls.data_convert(0, Communication.data(1, dp1, pyro)),
                 'currentTime': num})
            data_list_2.append(
                {'upPre': cls.data_convert(0, Communication.data(1, up2, pyro)),
                 'downPre': cls.data_convert(0, Communication.data(1, dp2, pyro)),
                 'currentTime': num})
            data_list_3.append(
                {'upPre': cls.data_convert(0, Communication.data(1, up3, pyro)),
                 'downPre': cls.data_convert(0, Communication.data(1, dp3, pyro)),
                 'currentTime': num})
            data_list_4.append(
                {'upPre': cls.data_convert(0, Communication.data(1, up4, pyro)),
                 'downPre': cls.data_convert(0, Communication.data(1, dp4, pyro)),
                 'currentTime': num})
        num += 1.5
