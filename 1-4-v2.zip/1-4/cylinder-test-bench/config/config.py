import configparser

"""
displacement_offset:                位移允许偏差    h
depressurization_scope:             降压范围        q
pressure_keep:                      保压压力        p
journey_time:                       行程稳定时长    t1
pressure_time:                      保压稳态时长    t2
stretched_num:                      伸出次数        stretched_num
pression_middle:                    中间保压        gender
"""

class Config(object):
    def __init__(self):
        self.conf = configparser.ConfigParser()
        self.conf.read('./config/config.conf')

    def get_conf(self):
        displacement_offset = int(self.conf.get("moxa", "displacement_offset"))
        depressurization_scope = float(self.conf.get("moxa", "depressurization_scope"))
        journey_time = int(self.conf.get("moxa", "journey_time"))
        pressure_time = int(self.conf.get("moxa", "pressure_time"))
        pressure_keep = int(self.conf.get("moxa", "pressure_keep"))
        stretched_num = int(self.conf.get("moxa", "stretched_num"))
        pressure_middle = int(self.conf.get("moxa", "pressure_middle"))
        return displacement_offset, depressurization_scope, journey_time, pressure_time, pressure_keep, stretched_num, pressure_middle

    def set_config(self, req_data, callback):
        print('修改了：', req_data)
        displacement_offset = req_data["displacement_offset"]
        depressurization_scope = req_data["depressurization_scope"]
        journey_time = req_data["journey_time"]
        pressure_time = req_data["pressure_time"]
        pressure_keep = req_data["pressure_keep"]
        pressure_middle = req_data["pressure_middle"]
        stretched_num = req_data["stretched_num"]

        self.conf.set("moxa", "displacement_offset", str(displacement_offset))
        self.conf.set("moxa", "depressurization_scope", str(depressurization_scope))
        self.conf.set("moxa", "journey_time", str(journey_time))
        self.conf.set("moxa", "pressure_time", str(pressure_time))
        self.conf.set("moxa", "pressure_keep", str(pressure_keep))
        self.conf.set("moxa", "stretched_num", str(stretched_num))
        self.conf.set("moxa", "pressure_middle", str(pressure_middle))

        with open("./config/config.conf", "w") as fp:
            self.conf.write(fp)
        callback()

