/**
 * @name 折线，表格初始化
*/
!function () {
  var testBoardArrayLeng = globalData.testBoardArray.length
  for(var i = 0; i < testBoardArrayLeng; i ++){
    var item = globalData.testBoardArray[i]
    globalData.testBoardArray[i] = new TestBoardRender({ testboardId: '#test-board-' + item })
  }
}()
/**
 * @name 油缸类型选择
*/
$('#oilTypeClick').click(function (e){
  e.stopPropagation()
  $("#check_wrap").is(":hidden") ? $("#check_wrap").show() : $("#check_wrap").hide()
})
$('#check_wrap .oil_check').on('click', '.form-check', function (e) {
  e.stopPropagation()
  const no = $(this).attr('data-no')
  const title = $(this).attr('data-title')
  $('#oilTypeValue').val(title)
  $('#oilTypeValue').attr('data-no', no)
  $('#oilTypeValue').attr('data-title', title)
  globalData.params.oil_cylinder_type = no
  $('.oil_check .form-check').removeClass("redio-action")
  $(this).addClass("redio-action")
  $("#check_wrap").hide()
})

/**
 * @name pyqt通信
*/
pyqtGetData(function(pyData) {
  try {
    pyData = JSON.parse(pyData)
  } catch {
    // pyData
  }
  globalData.response = pyData
  var isStopCause    = globalData.isStopCause
  var isEnterResult  = globalData.isEnterResult
  var testBoardArray = globalData.testBoardArray
  var data           = globalData.response.data,
      code           = globalData.response.code,
      status         = globalData.response.status,
      isTest         = globalData.response.isTest,
      message        = globalData.response.message,
      urgent_stop    = globalData.response.urgent_stop
      params         = globalData.params
  /**
   * 0、是否处于，配置修改状态
   * 1、判断code === 13 状态，连接超时
   * 2、是否急停
   * 3、系统泵站压力
   * 4、手动 一拖四 只有自动模式，手动模式取消，
   *    1、动态展示折线图
   * 5、0、各个测试台code判断
   *    1、判断isTest，实验结果
   *    2、自动并且处于实验中
   *    3、动态渲染折线图,动态展示表格
  */
  /* 0 */
  if($("#change-config")[0]){
    return
  }
  /* 1 */
  if (isConnectTimeout({ code: code, message: message })) return
  /* 2 */
  if (isStop(urgent_stop,isStopCause)) return
  if(!globalData.pyjs){
    return
  }
  testBoardArray.map((item,index)=>{
    /* 3 */
    $('.sys-wrap dl:eq(0) dd').text(data.dataList.systemPre.toFixed(2) + 'Mp')
    $('.sys-wrap dl:eq(1) dd').text(data.dataList.pumpPre.toFixed(2) + 'Mp')
    /* 4.1 */
    // if (autoOrManual(status)) {
    //   // TODO: 在这里要添加自动手动 元素界面状态
    //   item.upDataEchart(echartReconstruction(data.dataList, index),status)
    //   return
    // }
    /* 5.0 */
    item.showModal(testOilCode({ codeList: code, messageList: message, index: index }))
    if(!isTest){
      /* 5.1 */
      isEnterResult&&item.tabResult(()=>{
        globalData.isEnterResult = false
      })
      /* 5.2 */
      return
    }
    /* 5.3 */
    item.upDataRend(data.dataList,data.preDict, index)
  })
})

/**
 * @name 按键，回车
*/
document.onkeyup = function (e) {
  e.stopPropagation()
  let keyCode = e.keyCode || e.which || e.charCode
  var testBoardArray = globalData.testBoardArray
  var code           = globalData.response.code,
      status         = globalData.response.status,
      isTest         = globalData.response.isTest,
      message        = globalData.response.message,
      urgent_stop    = globalData.response.urgent_stop
  /**
   * 0、是否处于，配置修改状态
   * 1、是否急停
   * 2、是否超时连接 code === 13
   * 3、是否手动
   * 4、是否实验中
   * 5、表单验证
   * 6、数据初始化
   * 7、表单提交开始实验
  */
  if (keyCode === 13) {
    $("#check_wrap").hide()
    /* 0 */
    if($("#change-config #form-wrap")[0]){
      return
    }
    /* 1 */
    if(urgent_stop){
      toast({message:'正处于急停状态！'})
      return
    }
    /* 2 */
    if(code===13){
      toast({message:'正处于超时链接状态！'})
      return
    }
    /* 3 */
    // if(autoOrManual(status)){
    //   toast({message:'正处于手动状态！'})
    //   return
    // }
    /* 4 */
    if(isTest){
      toast({message:'正在实验中！'})
      return
    }
    /* 5 */
    const oil_test_array = []
    for(var index = 0; index < testBoardArray.length; index ++ ){
      var item = testBoardArray[index]
      oil_test_array.push(item.getTestBoardNum(index))
      item.initEnter()
    }
    globalData.params = {
      user_no: $('#userNoValue').val().trim(), // 用户编号
      construction_no: $('#constructionValue').val().trim(), // 施工号
      product_no: [oil_test_array[0].product_no, oil_test_array[1].product_no, oil_test_array[2].product_no, oil_test_array[3].product_no], // 产品编号
      oil_one: oil_test_array[0].oli_type,
      oil_two: oil_test_array[1].oli_type,
      oil_three: oil_test_array[2].oli_type,
      oil_four: oil_test_array[3].oli_type,
      oil_cylinder_type: $('#oilTypeValue').attr('data-no'), // 油缸类型
      test_type: 1, // 电压，电流
      oilcylinder_length: 0 // 油缸长度
    }
    if(!formVerify(globalData.params)) return
    /* 6 */
    resetGlobalData(function () {
      // globalData.isStopCause   = true
      // globalData.isEnterResult = true
      /* 7 */
      globalData.pyjs.no_displacement_start(JSON.stringify(globalData.params), function (data){
        globalData.isStopCause   = true
        globalData.isEnterResult = true
        pyLog({message: data})
      })
    })

  }
}
/**
 * @name 配置
*/
$('.config-wrap button').click((e)=>{
  e.stopPropagation()
  $("#check_wrap").hide()
  var code           = globalData.response.code,
      isTest         = globalData.response.isTest,
      urgent_stop    = globalData.response.urgent_stop
  if(urgent_stop){
    toast({message:'正处于急停状态！'})
    return
  }
  if(code===13){
    toast({message:'正处于超时链接状态！'})
    return
  }
  if(isTest){
    toast({message:'正在实验中'})
    return
  }
  showConfigUi()
})
