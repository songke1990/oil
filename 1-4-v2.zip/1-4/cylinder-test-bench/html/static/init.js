
/**
 * @name 弹层-modal
*/
var modal = function (data,isStopCause) {
  var title          = data.title || '提示',
      success        = data.success || null,
      message        = data.message,
      selector       = data.selector,
      maskActin      = data.maskActin || false,     // 是否可以点击遮罩层
      modalClass     = data.modalClass || ''
      showAction     = data.showAction || false,    // 是否显示 按钮
      isStopCause    = isStopCause || false
      renderAllReady = data.renderAllReady || null
  $("#check_wrap").hide()
  var titleStr = title ? '<p class="modal-wrap-title">'+ title +'</p>': ''
  var buttonStr = showAction ?
      '<div class="modal-wrap-content-foot">'+
        '<button class="modal-wrap-confirm">确定</button>'+
      '</div>' : ''
  var htmlStr = 
      '<div class="modal-wrap-main '+ modalClass +'">'+
        '<div class="modal-wrap-content">'+
          titleStr+
          '<div class="modal-wrap-content-body">'+ message +'</div>'+
          buttonStr+
        '</div>'+
      '</div>'
  $(selector?selector:'body').append(htmlStr)
  // 点击遮罩层
  maskActin&&$('.modal-wrap-main').click(function(e){
    e.stopPropagation()
    $(".modal-wrap-main").remove()
  })
  // 渲染完成
  renderAllReady&&renderAllReady()

  // 确定
  showAction&&$(`.modal-wrap-main .modal-wrap-confirm`).click(function(e){
    e.stopPropagation()
    success&&success()
  })
  // 防止事件穿透
  $(`body .modal-wrap-content`).click(function(e){
    e.stopPropagation()
  })
  
}

/**
 * @name 弹层-toast
*/
var toastTimeout = null
var toast = function (data) {
  var message  = data.message,
      selector = data.selector,
      duration = data.duration || 1500
  $("#check_wrap").hide()
  clearTimeout(toastTimeout)
  var htmlStr = 
      '<div id="toast-wrap">'+
        '<div class="toast-wrap-content">'+ message +'</div>'+
      '</div>'
  $("#toast-wrap").remove()
  $(selector?selector:'body').append(htmlStr)
  toastTimeout = setTimeout(function () {
    $("#toast-wrap").remove()
  },duration)
}

/**
 * @name 自动或手动
*/
var autoOrManual = function (status) {
  if(status){
    // 手动
    modal({
      message: '当前处于手动模式！'
    })
    return true
  }else{
    // 自动
    $(".modal-wrap-main").remove()
    return false
  }
}

/**
 * @name 是否急停
 * 1、初始化急停，只展示急停弹框，不弹出急停原因
 * 2、自动模式下急停，并且实验中急停，弹出急停原因表单
 * 3、手动模式下急停，只展示急停弹框，不弹出急停原因
 * 4、非急停状态
*/
var isStop = function (urgent_stop,isStopCause) {

  if(typeof urgent_stop == 'number' && urgent_stop && isStopCause){
    /* 2 */
    !$(".stop-wrap")[0]&&modal({
      message: '当前处于急停状态！',
      modalClass: 'stop-wrap'
    },true)
    stopCause()
    return true
  }
  /* 1 || 3 */
  if(typeof urgent_stop !== 'number' || urgent_stop){
    !$(".stop-wrap")[0]&&modal({
      message: '当前处于急停状态！',
      modalClass: 'stop-wrap'
    })
    return true
  }
  /* 4 */
  if(!urgent_stop){
    $(".stop-wrap").remove()
    return false
  }
}

/**
 * @name 是否连接超时
*/
var isConnectTimeout = function (data) {
  var code      = data.code,
      message   = data.message
      showModal = data.showModal || true
  if(code === 13){
    if(!$('.no-connect-wrap')[0]){
      showModal&&modal({
        message: message,
        modalClass: 'no-connect-wrap'
      })
    }
    return true
  }else {
    $(".no-connect-wrap").remove()
    return false
  }
}

/**
 * @name 各个测试油缸code判断
*/
var testOilCode = function (data) {
  var index       = data.index
      codeList    = data.codeList
      messageList = data.messageList
  return {
    code: codeList[index],
    message: messageList[index]
  }
}

/**
 * @name 折线图数据重构
*/
var echartReconstruction = function (data,index) {
  if(data){
    return {
      upPre: data.upPre[index],
      downPre: data.downPre[index],
      currentTime: data.currentTime
    }
  }
}

/**
 * @name 表格数据重构
*/
var tableReconstruction = function (data,index) {
  if(data){
    return {
      pre_drop: data.pre_drop[index],
      pre_time: data.pre_time,
      pre_info: data.pre_info,
      pre_value: data.pre_value[index],
      bool_value: data.bool_value[index],
      pre_drop_first: data.pre_drop_first[index]
    }
  }
}

/**
 * @name 校验
*/
var formVerify = function (params) {
  var formVerifyInfo = [
        {
          key: 'user_no',
          message: '请输入工号！'
        },
        {
          key: 'construction_no',
          message: '请输入施工号！'
        },
        {
          key: 'oil_cylinder_type',
          message: '请选择油缸类型！'
        },
        {
          key: 'product_no',
          message: '请输入产品编号！'
        }
      ]
  var isTest = true
  var length = formVerifyInfo.length
  for(var i = length-1; i>=0; i--){
    var item = formVerifyInfo[i]
    if(item.key!=='product_no'){
      if(!params[item.key]) {
        isTest = false
        !isTest&&toast({message:item.message})
      } 
    }else{
      isTest = params[item.key].some(item2=>item2)
      !isTest&&toast({message:item.message})
    }
  }
  return isTest
}

/**
 * 重置 globalData
*/
var resetGlobalData = function (callback) {
  // globalData.params = {
  //   user_no: '', // 用户编号
  //   oil_one: 0,
  //   oil_two: 0,
  //   oil_four: 0,
  //   oil_three: 0,
  //   test_type: 1, // 电压，电流
  //   oil_length: '', // 油缸长度
  //   product_no: ['','','',''], // 产品编号
  //   construction_no: '', // 施工号
  //   oil_cylinder_type: '' // 油缸类型
  // }
  globalData.response = {
    code: globalData.response.code,
    status: globalData.response.status,
    isTest: globalData.response.isTest,
    message: globalData.response.message,
    urgent_stop: globalData.response.urgent_stop,
    data: {
      /* 压力数据 */
      preDict: {
        pre_info: '', // 当前保压阶段说明
        pre_time: '', // 保压时间
        pre_drop: ['','','',''], // 第二次压力差
        pre_value: ['','','',''], // 压力值
        bool_value: ['','','',''], // 压力bool值
        pre_drop_first: ['','','',''] // 第一次压力差
      },
      /* 折线图 */
      dataList: {
        upPre: ['','','',''], // 上腔压
        pumpPre: '', // 泵压
        downPre: ['','','',''], // 下腔压
        systemPre: '', // 系统压
        currentTime: '' // 当前时间
      }
    }
  }
  callback&&callback()
}

/**
 * @name 急停原因
*/
var stopCause = function () {
  var htmlStr =
      '<form id="stopCauseForm" class="stopCause-wrap">'+
        '<div data-testNum="1" class="stopCause-item-wrap">'+
          '<label for="1">1号工位</label>'+
          '<input id="1" type="text" value="无" name="1">'+
          '<ul class="stopCause-type-ul">'+
              '<li>外缸漏液</li>'+
              '<li>导向套漏液</li>'+
              '<li>其他</li>'+
              '<li>无</li>'+
          '</ul>'+
        '</div>'+
        '<div data-testNum="2" class="stopCause-item-wrap">'+
          '<label for="2">2号工位</label>'+
          '<input id="2" type="text" value="无" name="2">'+
          '<ul class="stopCause-type-ul">'+
              '<li>外缸漏液</li>'+
              '<li>导向套漏液</li>'+
              '<li>其他</li>'+
              '<li>无</li>'+
          '</ul>'+
        '</div>'+
        '<div data-testNum="3" class="stopCause-item-wrap">'+
          '<label for="3">3号工位</label>'+
          '<input id="3" type="text" value="无" name="3">'+
          '<ul class="stopCause-type-ul">'+
              '<li>外缸漏液</li>'+
              '<li>导向套漏液</li>'+
              '<li>其他</li>'+
              '<li>无</li>'+
          '</ul>'+
        '</div>'+
        '<div data-testNum="4" class="stopCause-item-wrap">'+
          '<label for="4">4号工位</label>'+
          '<input id="4" type="text" value="无" name="4">'+
          '<ul class="stopCause-type-ul">'+
              '<li>外缸漏液</li>'+
              '<li>导向套漏液</li>'+
              '<li>其他</li>'+
              '<li>无</li>'+
          '</ul>'+
        '</div>'+
      '</form>'
  
  !$(".modal-stop-cause-wrap")[0]&&modal({
    title: '急停原因',
    modalClass: 'modal-stop-cause-wrap',
    message:htmlStr,
    showAction: true,
    maskActin: false, // 是否可以点击遮罩层
    success (){
      var formData = $('#stopCauseForm').serializeArray()
      //params
      formData.map((item,index)=>{
        var stopCause = {
          record_no: globalData.response.testNo[Number(item.name)-1],
          error_message: item.value
        }
        globalData.params.product_no[index]&&globalData.pyjs.post_fault(JSON.stringify(stopCause))
      })
      resetGlobalData()
      globalData.isStopCause = false
      $(".modal-stop-cause-wrap").remove()
    },
    renderAllReady () {
      // 显示故障类型
      $('.modal-wrap-content-body').on('click', '.stopCause-item-wrap', function (e){
        e.stopPropagation()
        $('.stopCause-type-ul').hide()
        $(this).find('.stopCause-type-ul').show()
      })
      // 选择故障类型
      $('.modal-wrap-content-body').on('click', '.stopCause-type-ul li', function (e){
        e.stopPropagation()
        $(this).parent().siblings('input').val($(this).text())
        $(this).parent().hide()
      })
      // 点击外部区域，隐藏故障类型原因弹层
      $('.modal-wrap-main,.modal-wrap-content').click(function(e){
        e.stopPropagation()
        $('.stopCause-type-ul').hide()
      })
    }
  },true)
}
/**
 * @name pyqt，数据传输
*/
const pyqtGetData = function (callback) {
  if(globalData.pyjs){
    setInterval(function () {
      globalData.pyjs.get_data("界面接收到了队列数据", function (data) {
        data = JSON.parse(data)
        callback(data)
      })
    }, 1500)
  }else{
    setInterval(function () {
      callback(globalData.response)
    }, 1500)
  }
}

!function (data) {
  /**
   * @name 油缸类型，初始化渲染
  */
  for(var i = 0; i < OIL_TYPE_CONFIG.length; i++){
    var item = OIL_TYPE_CONFIG[i]
    data += 
    '<div class="form-check" data-no="'+ item.no +'" data-title="'+ item.title +'">'+
      '<div>'+
        '<div class="action-border">'+
            '<input type="radio" name="oil_cylinder_type" id="'+ item.no +'" value="'+ item.no +'">'+
            '<label for="'+ item.no +'">'+item.title+'</label>'+
          '</div>'+
      '</div>'+
    '</div>'
  }
  $('.oil_check').html(data)
}('')
