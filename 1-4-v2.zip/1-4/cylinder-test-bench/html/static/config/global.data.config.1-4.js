var globalData = {
  pyjs: null,
  isStopCause: false, // 是否弹出急停原因（回车开始实验置为true，急停原因提交后置为false）
  isEnterResult: false, //是否计算并显示实验结果（回车开始实验置为true，当isTest为0并且表格列表不为空计算，计算完毕置为false）
  wxTest: null, // websocket 测试
  testBoardArray: [1, 2, 3, 4],
  params: {
    user_no: '', // 用户编号
    oil_one: 0,
    oil_two: 0,
    oil_four: 0,
    oil_three: 0,
    test_type: 1, // 电压，电流
    product_no: ['','','',''], // 产品编号
    construction_no: '', // 施工号
    oil_cylinder_type: '', // 油缸类型
    oilcylinder_length: '', // 油缸长度
  },
  response: {
    code: ['','','',''],
    status: 0, // 1:手动；0:自动
    testNo: ['','','',''], // 唯一值
    isTest: 0, // 0:是否实验；1:实验中 ??????????
    message: ['','','',''], //  试验成功 初始化超时 伸出超时 增压超时 收回超时
    // urgent_stop: '', // 1:急停；0:非急停
    urgent_stop: 0, // 1:急停；0:非急停
    data: {
      /* 压力数据 */
      preDict: {
        pre_info: '', // 当前保压阶段说明
        pre_time: '', // 保压时间
        pre_drop: ['','','',''], // 第二次压力差
        pre_value: ['','','',''], // 压力值
        bool_value: ['','','',''], // 压力bool值
        pre_drop_first: ['','','',''] // 第一次压力差
      },
      /* 折线图 */
      dataList: {
        upPre: ['','','',''], // 上腔压
        pumpPre: 0, // 泵压
        downPre: ['','','',''], // 下腔压
        systemPre: 0, // 系统压
        currentTime: '' // 当前时间
      }
    }
  }
}
/**
 * @name pyqt通信初始化
*/
var pyqtInit = function () {
  try {
    new QWebChannel(qt.webChannelTransport, function (channel) {
      globalData.pyjs = channel.objects.pyjs
    })
  }catch {
    console.log('无法构建pyqt5，请确认是否安装pyqt5环境')
  }
}
/**
 * @name py日志
*/
var pyLog = function (data) {
  try {
    globalData.pyjs.printPy(JSON.stringify(data))
  } catch {
    console.log(data)
  }
}
pyqtInit()
