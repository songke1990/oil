function TestBoardRender (data) {
  var testboardId  = data.testboardId
  this.tableId     = testboardId + ' .tbody-wrap'
  this.echartId    = testboardId + ' .echart-wrap'
  this.modalBox    = testboardId + ' .modal-wrap-test'
  this.resultBox   = testboardId + ' .all-result-wrap'
  this.testboardId = testboardId
  this.testBoardNum    = null
  this.echart          = null
  this.pyqt5Py         = null
  this.product_no      = ''
  // 表格
  this.tableList = []
  this.htmlStr   = ''
  // 折线图
  this.upPre       = []
  this.downPre     = []
  this.currentTime = []

  this.init()
}

TestBoardRender.prototype = {

  /**
   * @name 初始化
  */
  init: function () {
    var that = this
    // 表格
    this.tableList = []
    this.htmlStr   = ''
    // 折线图
    this.upPre       = []
    this.downPre     = []
    this.currentTime = []
    this.testBoardNumJudge()
    this.initRender(function(){
      that.echartInit()
      that.tableInit()
    })
  },

  // 回车 13 初始化
  initEnter: function () {
    // 表格
    this.tableList = []
    this.htmlStr   = ''
    // 折线图
    this.upPre       = []
    this.downPre     = []
    this.currentTime = []

    this.hideResult()
    this.hideModal()
    echarts.init($('#test-board-1 .echart-wrap')[0]).setOption(this.echartOptions())
    echarts.init($('#test-board-2 .echart-wrap')[0]).setOption(this.echartOptions())
    echarts.init($('#test-board-3 .echart-wrap')[0]).setOption(this.echartOptions())
    echarts.init($('#test-board-4 .echart-wrap')[0]).setOption(this.echartOptions())
    this.tableInit()
  },

  initRender: function (callback) {
    var template = 
        '<div class="test-board-header">'+
          '<div class="test-board-header-title">' + this.testBoardNum + '号工位</div>'+
          '<div class="test-board-header-input-wrap">'+
            '<div class="input-wrap">'+
              '<div class="label">产品编号</div>'+
              '<input id="input-'+ this.testBoardNum +'" class="test-board-input" type="text" data-testNum="'+ this.testBoardNum +'" placeholder="请输入">'+
            '</div>'+
          '</div>'+
        '</div>'+
        '<div class="render-wrap">'+
          '<div class="test-board-echart-wrap">'+
            '<div class="echart-wrap"></div>'+
          '</div>'+
          '<div class="test-board-table-wrap">'+
            '<table border="0">'+
              '<thead>'+
                '<tr>'+
                  '<th>项目</th>'+
                  '<th>值(mpa)</th>'+
                  '<th>保压时常(s)</th>'+
                  '<th>压降(mpa)<br /><span>(前阶段/后阶段)</span></th>'+
                  '<th>结果</th>'+
                '</tr>'+
              '</thead>'+
              '<tbody class="tbody-wrap"></tbody>'+
            '</table>'+
          '</div>'+
        '</div>'
    $(this.testboardId).html(template)
    callback()
  },

  productNoClear: function () {
    //
    // $(`${this.testboardId} input`).val('')
    $(`.test-board-input`).val('')
  },

  testBoardNumJudge: function  () {
    switch (this.testboardId) {
      case '#test-board-1':
        this.testBoardNum = 1
        break
      case '#test-board-2':
        this.testBoardNum = 2
        break
      case '#test-board-3':
        this.testBoardNum = 3
        break
      case '#test-board-4':
        this.testBoardNum = 4
        break
    }
  },

  /**
   * @name 折线图
  */
  echartInit: function () {
    var that = this
    // 折线图
    this.upPre           = []
    this.echart          = echarts.init($(this.echartId)[0])
    this.downPre         = []
    this.currentTime     = []
    
    this.echart.setOption(this.echartOptions())
    window.addEventListener("resize", function () {
      that.echart.resize()
    })
  },

  echartOptions: function () {
    return {
      color: ['#6179b7', '#c27e7f'],
      xAxis: {
        type: 'category',
        data: this.currentTime,
      },
      yAxis: {
          type: 'value',
          min: 0,
          max: 70,
          splitNumber: 10
      },
      grid: {
          left: '5%',
          right: '4%',
          top: '6%',
          bottom: '8%'
      },
      series: [
        {
          symbol: 'none',
          smooth: true,
          data: this.upPre,
          type: 'line'
        },
        {
            symbol: 'none',
            smooth: true,
            data: this.downPre,
            type: 'line'
        }
      ]
    }
  },
  upDataRend: function (data,tabData,index) {
    this.tableUpData(tabData,index)
    if(data){
      var upPre       = data.upPre[index]
          downPre     = data.downPre[index]
          currentTime = data.currentTime
      if(!this.product_no){
        return
      }
      this.currentTime.push(currentTime)
      this.upPre.push(upPre)
      this.downPre.push(downPre)
      // if(status&&this.currentTime.length>10){
      //   /* 手动，但不能无限增加数据，最多900条数据 */
      //   this.currentTime.splice(0, 1)
      //   this.upPre.splice(0, 1)
      //   this.downPre.splice(0, 1)
      // }
      this.echart.setOption(this.echartOptions())
    }
  },

  /**
   * @name 表格
  */
  tableInit: function () {
    const initData       = this.tableTemplate() + this.tableTemplate() + this.tableTemplate() + this.tableTemplate()
    // 表格
    this.htmlStr   = ''
    this.tableList = []

    this.hideResult()
    $(this.tableId).html(initData)
  },

  tableTemplate: function (data) {
    var template = ''
    if(data){
      var result = data.bool_value ? '<td class="sucess">√</td>' : '<td class="error">x</td>'
      template = 
        '<tr>'+
          '<td>'+ data.pre_info +'</td>'+
          '<td>'+ data.pre_value.toFixed(2) +'</td>'+
          '<td>'+ data.pre_time +'</td>'+
          '<td>'+ data.pre_drop_first.toFixed(2) +'/'+ data.pre_drop.toFixed(2) +'</td>'+
          result+
        '</tr>'
    }else{
      template =
      '<tr>'+
        '<td></td>'+
        '<td></td>'+
        '<td></td>'+
        '<td></td>'+
        '<td></td>'+
      '</tr>'
    }
    return template
  },

  tableUpData: function (data,index) {
    var tabArray = []
    if(JSON.stringify(data) == '{}' || !this.product_no){
      return
    }
    data = {
      pre_drop: data.pre_drop[index],
      pre_time: data.pre_time,
      pre_info: data.pre_info,
      pre_value: data.pre_value[index],
      bool_value: data.bool_value[index],
      pre_drop_first: data.pre_drop_first[index]
    }
    this.htmlStr = ''
    this.tableList.push(data)
    if(this.tableList.length<4){
       var leng = 4 - this.tableList.length
       tabArray = [...this.tableList,...new Array(leng)]
    }
    tabArray.map(item=>{
      this.htmlStr += this.tableTemplate(item)
    })
    $(this.tableId).html( this.htmlStr)
  },

  /* 表格结果判断 */
  tabResult: function (cllback) {
    if(!this.product_no){
      return
    }

    if(this.tableList.length){
      if(this.tableList.every(item=>item.bool_value)){
        this.resultSuccess()
      }else{
        this.resultError()
      }
      this.productNoClear()
      cllback&&cllback()
    }
  },

  // 去除 合格不合格标签，每次都需要初始化
  hideResult: function () {
    $(this.resultBox).remove()
  },

  resultSuccess: function () {
    var template = 
        '<div class="all-result-wrap">'+
          '<img src="./static/img/success.png" alt="">'+
        '</div>'
    $(this.testboardId).append(template)
  },

  resultError: function () {
    var template = 
        '<div class="all-result-wrap">'+
          '<img src="./static/img/error.png" alt="">'+
        '</div>'
    $(this.testboardId).append(template)
  },

  /**
   * @name 获取有数据的实验台号
  */
  getTestBoardNum: function (index) {
    var value = $(`#input-${index+1}`).val().trim()
    this.product_no = value
    return {
      product_no: value,
      oli_type: value ? 1 : 0
    }
  },

  /**
   * @name 模态窗
  */
  showModal: function (data,config) {
    if(!this.product_no){
      return
    }
    var that    = this
    var code    = data.code,
        message = data.message
    var configInit = {
          title: config&&config.title || `编号：${this.product_no}`,
          content: config&&config.content || '',
          showAction: config&&config.showAction || false,
          maskActin: config&&config.maskActin || false,
          success: null
        }
    if(code){
      this.productNoClear()
      this.hideModal()
      configInit.content = message
      var title      = configInit.title,
          content    = configInit.content,
          success    = configInit.success,
          maskActin  = configInit.maskActin,
          showAction = configInit.showAction

      var action = showAction ? 
          '<div class="modal-test-btn">'+
            '<button class="modal-test-cancel">取消</button>'+
            '<button class="modal-test-confirm">确定</button>'+
          '</div>'
          : ''
      var template = 
          '<div class="modal-wrap-test">'+
            '<div class="modal-content-test-wrap">'+
              '<div class="modal-test-title">'+ title +'</div>'+
              '<div class="modal-test-content">'+ content +'</div>'+
              action+
            '</div>'+
          '</div>'
      $(`${this.testboardId} .render-wrap`).append(template);
      maskActin&&$(this.modalBox).click(function(e){
        e.stopPropagation()
        that.hideModal()
      })
      showAction&&$(this.modalBox + ' .modal-test-cancel').click(function(e){
        e.stopPropagation()
        that.hideModal()
      })
      
      showAction&&$(this.modalBox + ' .modal-test-confirm').click(function(e){
        e.stopPropagation()
        const paramsData = {
          testboardId: that.testboardId
        }
        success&&success(paramsData)
        that.hideModal()
      })
      $(this.modalBox + ' .modal-content-test-wrap').click(function(e){
        e.stopPropagation()
      })
    }
  },

  hideModal: function () {
    $(this.modalBox).remove()
  }

}
