const ConfigUi = () => {
  const configHtml =
  `
  <div id="change-config">
  <div id="form-wrap" >
    <form method="post" onsubmit="return false" action="##">
      <div class="form-head">
        <img src="./static/img/logoMini.png">
        <h1>郑煤机推移测试管理</h1>
      </div>
      <div class="input-item">
        <label class="input-item-text"><em style="color: red;">*</em> 保压稳态时长：</label>
        <input id="pressure_time" class="form-control" name="pressure_time" type="number" placeholder="请输入保压稳态时长">
        <span>s</span>
      </div>
      <div class="input-item">
        <label class="input-item-text"><em style="color: red;">*</em> 保压压力：</label>
        <input id="pressure_keep" class="form-control" name="pressure_keep" type="number" placeholder="请输入保压压力">
        <span>Mpa</span>
      </div>
      <div class="input-item">
        <label class="input-item-text"><em style="color: red;">*</em> 降压范围：</label>
        <input id="depressurization_scope" class="form-control" name="depressurization_scope" type="number" placeholder="请输入降压范围">
        <span>Mpa</span>
      </div>
      <div class="config-btn-wrap">
        <input id="cancel-btn" type="button" value="取消">
        <input id="submit-btn" type="button" value="提交">
      </div>
      
    </form>
  </div>
  </div>
  `
  return configHtml
}
const removeConfigUi = () => {
  $("#change-config").remove()
}
const changeConfigVerify = (params) => {
  let isPost = true
  let formVerifyInfo = [
    {
      key: 'pressure_time',
      message: '请输入保压稳态时长'
    },
    {
      key: 'pressure_keep',
      message: '请输入保压压力'
    },
    {
      key: 'depressurization_scope',
      message: '请输入降压范围'
    }
  ]
  for(var i = 0; i < formVerifyInfo.length; i++){
    let item = formVerifyInfo[i]
    if(!params[item.key].length){
      toast({message:item.message})
      isPost = false
      return
    }
  }
  return isPost
}
const configDataInit = () => {
  globalData.pyjs.get_config_pyqt('获取配置参数', (data)=>{
    data = JSON.parse(data)
    pyLog({
      message:'配置',
      data
    })
    let inputDom = $("#change-config #form-wrap input[name='pressure_middle']")
    $("#change-config #form-wrap #depressurization_scope").val(data.depressurization_scope)
    $("#change-config #form-wrap #pressure_keep").val(data.pressure_keep)
    $("#change-config #form-wrap #pressure_time").val(data.pressure_time)
    if (data.pressure_middle) {
      for (let i in inputDom) {
        if (Number(inputDom.eq(i).val()) === data.pressure_middle) {
          inputDom[i].checked = true
        } else {
          inputDom[i].checked = false
        }
      }
    }
  })
}
const showConfigUi = (callback) => {
  $('body').append(ConfigUi())
  configDataInit()
  $("#change-config").on('click', '#submit-btn',(e)=>{
    e.stopPropagation()
    e.preventDefault()
    let datas = $('#form-wrap form').serializeArray()
    let params = {
      journey_time:           0,
      pressure_time:          datas.find(item => item.name == 'pressure_time').value.trim(),
      pressure_keep:          datas.find(item => item.name == 'pressure_keep').value.trim(),
      stretched_num:          0,
      pressure_middle:        0,
      displacement_offset:    0,
      depressurization_scope: datas.find(item => item.name == 'depressurization_scope').value.trim()
    }
    if(!changeConfigVerify(params)) return
    console.log('入参：', params)
    globalData.pyjs.change_config(JSON.stringify(params), ()=>{
      removeConfigUi()
    })
  })
  $("#change-config").on('click', '#cancel-btn',(e)=>{
    e.stopPropagation()
    e.preventDefault()
    removeConfigUi()
  })
}
