function websocketTest(callback) {
  var wsServer = 'ws://localhost:3001'
  globalData.wxTest = new WebSocket(wsServer)

  globalData.wxTest.onopen = function (e) {
    console.log("连接到wocket")
    sendMessage("李勇勇")
  }

  globalData.wxTest.onclose = function (e) {
    console.log("关闭连接", e)
  }

  globalData.wxTest.onmessage = function (e) {
    // console.log("接收数据: " + e.data)
    callback(e.data)
    // ws.close()
  }

  globalData.wxTest.onerror = function (e) {
    console.log('报错: ' + e.data, e)
  }

  var sendMessage = function (msg) {
    globalData.wxTest.send(msg);
    console.log("向服务器发送数据 : " + msg)
  }
}
