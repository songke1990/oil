// "application/x-www-form-urlencoded"
const http = ({
	httpIp = "http://localhost:81",
	api = '',
	param = {},
	contentType = 'application/json',
	type = "get"
} = {}) => {
	return new Promise((resolve, reject) => {
		$.ajax({
			dataType: 'json',
			url: `${httpIp}${api}`,
			contentType: contentType,
			data: param,
			type: type,
			success: function(result) {
				if (result.success) {
					resolve(result)
				} else {
					reject(result)
				}
			},
			error: function(res) {
				// 服务器异常
			}
		})
	})
}
const get_config = ()=>{
	return http({
		api:"/api/get_config",
		param:"",
		type:"get"
	})
}

const set_config = (data)=>{
	return http({
		api:"/api/set_config",
		param:JSON.stringify(data),
		type:"post"
	})
}