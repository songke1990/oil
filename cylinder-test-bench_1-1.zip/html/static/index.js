// $("#formtest .tab-input:eq(0)").focus()
/**
 * @name 油缸类型
*/
!function(){
  // 选择油缸类型，业务
  $(".oil_cylinder_type").bind({
      click: function (e) {
          e.stopPropagation()
          $("#check_wrap").is(":hidden") ? $("#check_wrap").css({display: "flex"}) : $("#check_wrap").hide()
      }
  })
  $("#capture").click(() => {
      $("#check_wrap").hide()
  })
  $('.oil_check').on('click', '.form-check', function (e) {
      e.stopPropagation()
      $('.oil_check .form-check').removeClass("redio-action")
      $(this).addClass("redio-action")
      const radioVal = $(this).find("input").val()
      const thisUpright = upright.filter(item => {
          if (item.no == radioVal) {
              return item
          }
      })
      $("#oil_cylinder_type").val(thisUpright[0].title)
      $("#check_wrap").hide()
      // 判断是否有位移
      if (radioVal == 1) {
          $('.is-show-name').css({
              'display': 'block'
          })
      } else {
          $('.is-show-name').css({
              'display': 'none'
          })
      }
  })
}()
/**
 * @name 初始化
*/
!function(){
  init()
  systemPreRender({
      data: {
          dataList: {
              pumpPre:0,
              systemPre:0
          }
      }
  })
  autoEchart(1)
}()
/**
 * @name pyqt 通信
*/
pyqtGetData((data)=>{
  try {
    data = JSON.parse(data)
  } catch {
    // pyData
  }
  if (data) {
    globalData.testNo = data.testNo
    globalData.isTest = data.isTest
    globalData.code = data.code
    globalData.urgent_stop = data.urgent_stop
    globalData.status = data.status
    if($("#change-config")[0]){
      return
    }
    pyLog({
      message: '数据',
      data
    })
    statusPy(data)
    /**
     * 手动模式，一直轮询
     * 自动，回车调用数据，结束，停止
     * 急停，停止调用
     * */
    if (data.urgent_stop) {
        // 急停
        return
    }
    
    systemPreRender(data)

    if (data.code && !data.urgent_stop && !data.status) {
        dataCode(data)
    }
    // 手动模式
    if (data.status) {
        data.isTest = 1
        echartRender(data)
        return
    }
    // 自动模式
    if (!data.status && data.isTest) {
        // 实验中并且非手动
        echartRender(data)
        tabRender(data)
    } else {
        // 再次开始实验初始化
        globalData.echsrtList = []
    }
  }
})
/**
 * @name 键盘事件
*/
!function(){
   /**
     * 键盘事件
     * 1、回车        -- 开始实验
     * 3、+键(107)    -- 启用或关闭小键盘
     * 4、/键(111)    -- 清空
     * 5、*键(106)    -- tab切换光标
     * 7、+  107      -- 显示隐藏虚拟键盘
     * */
    document.onkeyup = (e) => {
      e.stopPropagation()
      let keyCode = e.keyCode || e.which || e.charCode
      if($("#change-config")[0]){
        return
      }
      if (globalData.isExigency) {
        toast({message:"正处于急停状态！"})
        return;
      }
      if(globalData.code ==13){
        toast({message:"连接未建立，无法开始实验！"})
        return
      }
      if (globalData.isTest) {
        toast({message:"正处于实验阶段，无法开始下次实验！"})
        return;
      }
      if (keyCode === 13) {
        $("#check_wrap").hide()
        if (!$("#timeoutModelId").is(":hidden")) {
          $("#timeoutModelId").hide();
          return;
        }
        // 开始实验
        init(() => {
          startExperiment()
        })
      }
  }
  $(".btn-close").bind({
      click: function () {
        $("#timeoutModelId").hide()
      }
  })

  /**
   * 急停状态下，故障上报
   * */
  $('#faultTypeSubmit').click(function () {
      let messageType = $('.fault-type-box').val()
      if (messageType.toString().length < 2) {
          $('.fault-type-note').show()
      } else {
        globalData.pyjs.post_fault(`${JSON.stringify({
              record_no: globalData.testNo,
              error_message: messageType
          })}`, function () {
              globalData.isStartNow = false
              globalData.isPullFault = true
              $("#fault-model").hide()
          })
          $('.fault-type-note').hide()
      }
  })

  function startExperiment() {
      
      let datas = $('#formtest').serializeArray()
      var data = {
          oilcylinder_length: $('#length').val(),
          product_no: datas.find(item => item.name == 'product_no').value,
          user_no: datas.find(item => item.name == 'user_no').value,
          oil_cylinder_type: datas.find(item => item.name == 'oil_cylinder_type') ? datas.find(item => item.name == 'oil_cylinder_type').value : 0,
          test_type: datas.find(item => item.name == 'test_type').value,
          construction_no: datas.find(item => item.name == 'construction_no').value,
      }
      globalData.user_no = data.user_no
      globalData.product_no = data.product_no
      globalData.oilcylinder_length = data.oilcylinder_length
      globalData.test_type = data.test_type
      globalData.construction_no = data.construction_no
      globalData.oil_cylinder_type = data.oil_cylinder_type
      var verifyData = {
          user_no: data.user_no,
          construction_no: data.construction_no,
          product_no: data.product_no,
          oil_cylinder_type: data.oil_cylinder_type,
      }
      if (!formVerify(verifyData)) return
      
      $("#pre-table").html("")
      $("#displacement-table").html("")
      if (data.oil_cylinder_type == 1) {
          if (data.oilcylinder_length <= 0) {
              return $('.form_verify_length').show()
          } else {
              $('.form_verify_length').hide()
          }
          if (data.test_type.length <= 0) {
              return $('.form_verify_test_type').show()
          } else {
              $('.form_verify_test_type').hide()
          }
          if (data.test_type == 1) {
              // 有行程电压
              pyLog({
                message: "有行程电压"
              })
              globalData.pyjs.start(JSON.stringify(data), function (msg) {
                  globalData.isPullFault = false
                  globalData.isStartNow = true
              })
          } else {
              // 有行程电流
              pyLog({
                message: "有行程电流"
              })
              globalData.pyjs.electricity_start(JSON.stringify(data), function (msg) {
                  globalData.isPullFault = false
                  globalData.isStartNow = true
              })
          }
      } else {
          // 无行程
          pyLog({
            message: "无行程"
          })
          globalData.pyjs.no_displacement_start(JSON.stringify(data), function (msg) {
              globalData.isPullFault = false
              globalData.isStartNow = true
          })
      }
  }
}()
/**
 * @name 配置
*/
$('.config-change-wrap .button').click((e)=>{
  e.stopPropagation()
  $("#check_wrap").hide()
  var code           = globalData.code,
      status         = globalData.status,
      isTest         = globalData.isTest,
      urgent_stop    = globalData.urgent_stop
  if(urgent_stop){
    toast({message:'正处于急停状态！'})
    return
  }
  if(code===13){
    toast({message:'正处于超时链接状态！'})
    return
  }
  if(isTest){
    toast({message:'正在实验中'})
    return
  }
  if(status){
      toast({message:'正处于手动模式'})
      return
  }
  showConfigUi()
})