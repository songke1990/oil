function statusPy(data) {
    let status = data.status
    let urgent_stop = data.urgent_stop
    if (data.code == 13) {
        $(".example-text").html(`<span>${data.message}</span>`)
        $("#exampleModal").show()
    } else {
        $("#exampleModal").hide()
    }
    if (status == undefined || urgent_stop == undefined) {
        return
    }
    if (status) {
        // 手动
        $("#timeoutModelId").hide()
        autoEchart(3)
    } else {
        // 自动
        globalData.isExigency = false;
        $("#exampleModal").hide()
        autoEchart(1)
    }
    if (urgent_stop) {
        $("#timeoutModelId").hide()
        globalData.isExigency = true
        $(".example-text").html("<span>急停</span>")
        $("#exampleModal").show()
    } else {
        globalData.isExigency = false
        $("#exampleModal").hide()
    }
    if (urgent_stop && globalData.isStartNow && !globalData.isPullFault) {
        $("#fault-model").show()
    } else {
        // $("#fault-model").hide()
    }
}

const autoEchart = (data) => {
    const value = data == 1 ? "自动模式" : "手动模式"
    const autoOption = {
        tooltip: {
            formatter: '{a} <br/>{b} : {c}%'
        },
        toolbox: {
            feature: {
                restore: {},
                saveAsImage: {}
            }
        },
        series: [
            {
                type: 'gauge',
                radius: '100%',
                max: '4',
                min: '0',
                detail: {
                    formatter: value,
                    fontSize: 12
                },
                data: [
                    {
                        value: data,
                        name: '自动或手动'
                    }
                ],
                axisLine: {
                    show: true,
                    lineStyle: {
                        color: [[0.5, '#63869e'], [1, '#c23531']],
                        width: 10
                    }
                },
                splitLine: {
                    show: true,
                    color: '#c23531',
                    length: '25%',
                    width: 2,
                },
                axisLabel: {
                    show: false,
                },
                pointer: {
                    width: 2
                },
                title: {
                    offsetCenter: [0, -6],
                    fontSize: 12
                },
            }
        ]
    }
    let autoChart = echarts.init(document.getElementById('auto-pre-wrap')).setOption(autoOption)

}