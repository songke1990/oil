const globalData = {
	pyjs: null,
	user_no: '',
	product_no: '',
	oilcylinder_length: 960,
	isStartNow: false,
	isExigency: false,
	// 测试的唯一值
	testNo:'',
	isTest: 0,
	code: 0,
	urgent_stop: 0,
	status: 0,
	isPullFault: false,
	echsrtList: [],
	displacementList:[],
	preDictList:[]
};

/**
 * @name pyqt通信初始化
*/
!function(){
	try {
    new QWebChannel(qt.webChannelTransport, function (channel) {
      globalData.pyjs = channel.objects.pyjs
    })
  }catch {
    console.log('无法构建pyqt5，请确认是否安装pyqt5环境')
  }
}()

/**
 * @name py日志
*/
var pyLog = function (data) {
  try {
    globalData.pyjs.printPy(JSON.stringify(data))
  } catch {
    console.log(data)
  }
}
