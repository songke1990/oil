const upright = [
	{
		title: '推移-有位移传感器',
		no: 1
	},
	{
		title: '推移-无位移传感器',
		no: 2
	},
	{
		title: '(左、前)立柱',
		no: 3
	},
	{
		title: '(右、后)立柱',
		no: 4
	},
	{
		title: '平衡千斤顶',
		no: 5
	},
	{
		title: '侧推千斤顶',
		no: 6
	},
	{
		title: '抬底千斤顶',
		no: 7
	},
	{
		title: '一级护帮千斤顶',
		no: 8
	},
	{
		title: '二级护帮千斤顶',
		no: 9
	},
	{
		title: '三级护帮千斤顶',
		no: 10
	},
	{
		title: '伸缩梁千斤顶',
		no: 11
	},
	{
		title: '尾梁千斤顶',
		no: 12
	},
	{
		title: '插板千斤顶',
		no: 13
	},
	{
		title: '前梁千斤顶',
		no: 14
	},
	{
		title: '底调千斤顶',
		no: 15
	},
	{
		title: '移后溜千斤顶',
		no: 16
	},
	{
		title: '掩梁立柱',
		no: 17
	},
	{
		title: '侧帮千斤顶',
		no: 18
	},
	{
		title: '调推杆千斤顶',
		no: 19
	},
	{
		title: '调运输机千斤顶',
		no: 20
	},
	{
		title: '挡矸千斤顶',
		no: 21
	},
	{
		title: '推拉千斤顶',
		no: 22
	},
	{
		title: '顶梁调架千斤顶',
		no: 23
	},
	{
		title: '底座调架千斤顶',
		no: 24
	},
]