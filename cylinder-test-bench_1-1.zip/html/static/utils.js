/**
 * @name pyqt，数据传输
*/
const pyqtGetData = function (callback) {
    if(globalData.pyjs){
        setInterval(function () {
            globalData.pyjs.get_data("界面接收到了队列数据", function (data) {
            data = JSON.parse(data)
                callback(data)
            })
        }, 1500)
    }else{
        setInterval(function () {
            callback(globalData.response)
        }, 1500)
    }
}   
/**
 * @name 弹层-toast
*/
var toastTimeout = null
var toast = function (data) {
  var message  = data.message,
      selector = data.selector,
      duration = data.duration || 1500
  $("#check_wrap").hide()
  clearTimeout(toastTimeout)
  var htmlStr = 
      '<div id="toast-wrap">'+
        '<div class="toast-wrap-content">'+ message +'</div>'+
      '</div>'
  $("#toast-wrap").remove()
  $(selector?selector:'body').append(htmlStr)
  toastTimeout = setTimeout(function () {
    $("#toast-wrap").remove()
  }, duration)
}
/**
 * @name 油缸类型，初始化渲染
 */
 !function (data) {
    for (let i in upright) {
        var item = upright[i]
        data += 
            '<div class="form-check" data-no="'+ item.no +'" data-title="'+ item.title +'">'+
            '<div>'+
                '<div class="action-border">'+
                    '<input type="radio" name="oil_cylinder_type" id="'+ item.no +'" value="'+ item.no +'">'+
                    '<label for="'+ item.no +'">'+item.title+'</label>'+
                '</div>'+
            '</div>'+
            '</div>'
    }
    $(".oil_check").html(data)
  }('')
  /**
 * 表单验证
 * */
const formVerify = function (data) {
    let isPut = true;
    for (let i in data) {
        if (data[i] == '' || data[i] == '0') {
            toast({message: $(`.form_verify_${i}`).text()})
            return isPut = false
        } else {
            $(`.form_verify_${i}`).hide()
            isPut = true
        }
    }
    return isPut
}
/* ******************************************************************************************************* */
$(document).ready(function () {
    // 油缸行程
    $('.length-ul').find('li').click(function () {
        $('#length').val($(this).text())
    })
    $('#length').focus(function () {
        $('.length-ul').css({
            'opacity': '1'
        })
    })
    $('#length').blur(function () {
        $('.length-ul').css({
            'opacity': '0'
        })
    })
    // 故障类型逻辑
    $('.fault-type-box').click(function (e) {
        e.stopPropagation()
        $('.fault-type-ul').css({
            'visibility': 'visible'
        })
    })
    $('#fault-model').click(function (e) {
        $('.fault-type-ul').css({
            'visibility': 'hidden'
        })
    })
    $('.fault-type-ul>ul').find('li').click(function (e) {
        e.stopPropagation()
        $('.fault-type-box').val($(this).text())
        $('.fault-type-ul').css({
            'visibility': 'hidden'
        })
    })
});
/**
 * 清空
 * */
const reset = function () {
    $(`.tab-input`).map(index => {
        if ($(`.tab-input:eq(${index})`).is(":focus")) {
            $(`.tab-input:eq(${index})`).val("");
        }
    })
}

/**
 * 禁止特殊字符输入到input中,例如 +(调用虚拟键盘),*(切换),/(清空)
 * */
function disableInput() {
    $("#formtest input").bind("keydown", (e) => {
        let keyCode = e.keyCode || e.which || e.charCode
        if (keyCode == 106 || keyCode == 107 || keyCode == 111 || keyCode == 110) {
            e.preventDefault();
        }
    })
}


/**
 * 表格图表初始化
 * */
let preChartInit = function (option) {
    let preChart = echarts.init(document.getElementById('echart-pre-wrap'));
    preChart.setOption(option);
}
let displacementChartInit = function (option) {
    let displacementChart = echarts.init(document.getElementById('echart-displacement-wrap'));
    displacementChart.setOption(option);
}
/**
 * 初始化
 * */
let option = {
    xAxis: {
        type: 'category',
        data: []
    },
    yAxis: {
        type: 'value'
    },
    grid: {
        left: '4%',
        right: '5%',
        top: '6%',
        bottom: '8%'
    },
}
const init = function (callback) {
    globalData.echartList = []
    globalData.displacementList = []
    globalData.preDictList = []
    disableInput()
    let width = $(document.body).width()
    $("#echart-pre-wrap").width(width * 0.3);
    $("#echart-displacement-wrap").width(width * 0.3);
    preChartInit(option)
    displacementChartInit(option)
    let preDoc =
        `
	<tr class="first">
		<td>活塞腔实际保压压力</td>
		<td>0.00</td>
		<td>0</td>
		<td>0.00/0.00</td>
		<td class="green">√</td>
	</tr>
	<tr class="two">
		<td>活塞杆腔实际保压压力</td>
		<td>0.00</td>
		<td>0</td>
		<td>0.00/0.00</td>
		<td class="green">√</td>
	</tr>
	<tr class="first">
		<td>2/3活塞杆腔实际保压压力</td>
		<td>0.00</td>
		<td>0</td>
		<td>0.00/0.00</td>
		<td class="green">√</td>
	</tr>
	<tr class="two">
		<td colspan="4">结论</td>
		<td class="green">合格</td>
	</tr>
	`
    let displacementDoc =
        `
	<tr class="first">
		<td>1</td>
		<td>0.00</td>
		<td>0.00/0.00</td>
		<td>0.00</td>
		<td class="green">√</td>
	</tr>
	<tr class="two">
		<td>2</td>
		<td>0.00</td>
		<td>0.00/0.00</td>
		<td>0.00</td>
		<td class="green">√</td>
	</tr>
	<tr class="first">
		<td>3</td>
		<td>0.00</td>
		<td>0.00/0.00</td>
		<td>0.00</td>
		<td class="green">√</td>
	</tr>
	<tr class="two">
		<td>4</td>
		<td>0.00</td>
		<td>0.00/0.00</td>
		<td>0.00</td>
		<td class="green">√</td>
	</tr>
	<tr class="first">
		<td>5</td>
		<td>0.00</td>
		<td>0.00/0.00</td>
		<td>0.00</td>
		<td class="green">√</td>
	</tr>
	<tr class="two">
		<td colspan="4">结论</td>
		<td class="green">合格</td>
	</tr>
	`
    $('#pre-table').html(preDoc)
    $('#displacement-table').html(displacementDoc)
    callback ? callback() : ''
}
/**
 * 数据渲染
 * */
const echartRender = function (data) {
    if (data.status) {
        $(".table-wraper-item").hide()
        globalData.oilcylinder_length = 960
        if (globalData.echsrtList.length > 900) {
            globalData.echsrtList.splice(0, 1)
        }
    } else {
        $(".table-wraper-item").show()
    }
    // 折线图 (data.data.dataList && data.isTest)
    if (data.data.dataList && data.isTest) {
        globalData.echsrtList.push(data.data.dataList)
        let currentTime = []
        let realLength = []
        let upPre = []
        let downPre = []
        globalData.echsrtList.forEach(item => {
            if (!data.status) {
                currentTime.push(item.currentTime)
            }
            realLength.push(item.realLength)
            upPre.push(item.upPre)
            downPre.push(item.downPre)
        })
        echartDataRender(currentTime, realLength, upPre, downPre)
    }
}
const tabRender = function (data) {
    // 压力表
    if ("pre_info" in data.data.preDict) {
        globalData.preDictList.push(data.data.preDict)
        preDictTab(globalData.preDictList)
    }
    // 位移表格
    if ("measured_value" in data.data.displacementDict) {
        globalData.displacementList.push(data.data.displacementDict)
        displacementTab(globalData.displacementList)
    }
}
const systemPreRender = function (data) {
    // data.data.dataList.systemPre
    // data.data.dataList.pumpPre
    const systemOption = {
        tooltip: {
            formatter: '{a} <br/>{b} : {c}%'
        },
        toolbox: {
            feature: {
                restore: {},
                saveAsImage: {}
            }
        },
        series: [
            {
                type: 'gauge',
                radius: '100%',
                max: '70',
                min: '0',
                splitNumber: '7',
                detail: {
                    offsetCenter: ['0', '66%'],
                    formatter: function (value) {
                        return `${value.toFixed(2)}Mp`
                    },
                    fontSize: 12
                },
                data: [
                    {
                        value: data.data.dataList.systemPre,
                        name: '系统压'
                    }
                ],
                axisLine: {
                    show: true,
                    lineStyle: {
                        color: [[20 / 70, '#91c7ae'], [50 / 70, '#63869e'], [1, '#c23531']],
                        width: 10
                    }
                },
                splitLine: {
                    show: true,
                    color: '#c23531',
                    length: '25%',
                    width: 2,
                },
                axisTick: {
                    lineStyle: {
                        color: '#fff'
                    }
                },
                axisLabel: {
                    show: true,
                    distance: 0,
                },
                pointer: {
                    width: 2
                },
                title: {
                    offsetCenter: [0, -6],
                    fontSize: 12
                },
            }
        ]
    }
    const pumpOption = {
        tooltip: {
            formatter: '{a} <br/>{b} : {c}%'
        },
        toolbox: {
            feature: {
                restore: {},
                saveAsImage: {}
            }
        },
        series: [
            {
                type: 'gauge',
                radius: '100%',
                max: '70',
                min: '0',
                splitNumber: '7',
                detail: {
                    offsetCenter: ['0', '66%'],
                    formatter: function (value) {
                        return `${value.toFixed(2)}Mp`
                    },
                    fontSize: 12
                },
                data: [
                    {
                        value: data.data.dataList.pumpPre,
                        name: '泵站压'
                    }
                ],
                axisLine: {
                    show: true,
                    lineStyle: {
                        color: [[20 / 70, '#91c7ae'], [50 / 70, '#63869e'], [1, '#c23531']],
                        width: 10
                    }
                },
                splitLine: {
                    show: true,
                    color: '#c23531',
                    length: '25%',
                    width: 2,
                },
                axisTick: {
                    lineStyle: {
                        color: '#fff'
                    }
                },
                axisLabel: {
                    show: true,
                    distance: 0,
                },
                pointer: {
                    width: 2
                },
                title: {
                    offsetCenter: [0, -6],
                    fontSize: 12
                },
            }
        ]
    }
    let systemChart = echarts.init(document.getElementById('system-pre-wrap')).setOption(systemOption)
    let pumpChart = echarts.init(document.getElementById('pump-pre-wrap')).setOption(pumpOption)
}
const preDictTab = function (preDictList) {
    $('#pre-table').html('')
    let createDoc = ''
    let verdict = true
    if (preDictList.length) {
        preDictList.forEach((item, index) => {
            let className = index % 2 === 0 ? 'first' : 'two'
            let result = item.bool_value ? '√' : 'x'
            if (!item.bool_value) {
                verdict = false
            }
            createDoc +=
                `
                <tr class='${className}'>
					<td>${item.pre_info}</td>
					<td>${item.pre_value}</td>
					<td>${item.pre_time}</td>
					<td>${item.pre_drop_first}/${item.pre_drop}</td>
					<td class="${item.bool_value ? 'green' : 'red'}">${result}</td>
				</tr>
                `
        })
        let verdictDoc =
            `
               <tr class="two">
				<td colspan="4">结论</td>
				<td class="${verdict ? 'green' : 'red'}">${verdict ? '合格' : '不合格'}</td>
			</tr>
            `
        $('#pre-table').html(createDoc + verdictDoc)
    }
}
const displacementTab = function (displacementList) {
    $('#displacement-table').html('')
    let createDoc = ''
    let verdict = true
    if (displacementList.length) {
        displacementList.forEach((item, index) => {
            let className = index % 2 === 0 ? 'first' : 'two'
            let result = item.bool_value ? '√' : 'x'
            if (!item.bool_value) {
                verdict = false
            }
            createDoc +=
                `
                <tr class='${className}'>
					<td>${index + 1}</td>
					<td>${item.measured_value}</td>
					<td>${item.actual_value_max}/${item.actual_value}</td>
					<td>${item.deviation_value}</td>
					<td class="${item.bool_value ? 'green' : 'red'}">${result}</td>
				</tr>
                `
        })
        let verdictDoc =
            `
               <tr class="two">
				<td colspan="4">结论</td>
				<td class="${verdict ? 'green' : 'red'}">${verdict ? '合格' : '不合格'}</td>
			</tr>
            `
        $('#displacement-table').html(createDoc + verdictDoc)
    }
}


const echartDataRender = function (currentTime, realLength, upPre, downPre) {
    let preDictOption = {
        xAxis: {
            type: 'category',
            data: currentTime,
        },
        yAxis: {
            type: 'value',
            min: 0,
            max: 80,
            splitNumber: 11
        },
        grid: {
            left: '4%',
            right: '5%',
            top: '6%',
            bottom: '8%'
        },
        series: [{
            symbol: 'none',
            smooth: true,
            data: upPre,
            type: 'line'
        },
            {
                symbol: 'none',
                smooth: true,
                data: downPre,
                type: 'line'
            },
        ]
    }
    let displacementOption = {
        xAxis: {
            type: 'category',
            data: currentTime,
        },
        yAxis: {
            type: 'value',
            min: 0,
            max: Number(globalData.oilcylinder_length) + 40,
            splitNumber: 11
        },
        grid: {
            left: '8%',
            right: '5%',
            top: '6%',
            bottom: '8%'
        },
        series: [{
            symbol: 'none',
            smooth: true,
            data: realLength,
            type: 'line'
        },]
    }
    preChartInit(preDictOption)
    displacementChartInit(displacementOption)
}

const dataCode = (data) => {
    /**
     * code 1 2 3 4 5 6
     * message 试验成功 停止实验 初始化超时 伸出超时 增压超时 收回超时
     * isTest   0未实验 1 实验中
     * */
    let code = data.code
    let message = data.message
    globalData.isStartNow = false
    if(code == 13 || code == 2){
        return
    }
    //初始化超时 伸出超时 增压超时 收回超时
    //3 4 5 6
    $(".timeoutId-text").html(`<span>${message}</span>`)
    $("#timeoutModelId").show()
    // 施工号
    $(`.tab-input:eq(1)`).focus()
    // 产品编号
    $(`.tab-input:eq(2)`).blur()
}
