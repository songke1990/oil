/**
 *  <div id="inputWrap">
 *		<input id="input" type="text">
 *	</div>
 *	<div id="key-wrap"></div>
 *  let kb = new keyBody({
 *		keyBox: "#key-wrap",
 *		inputWrap: "#inputWrap"
 *	})
 *	kb.show()
 * */

// 1 定义虚拟键盘格式，并布局 lowercase uppercase
// 2 大小写切换 小键盘 NumberLock 状态下 的5按键 状态 12
// 3 点击或回车选中字母，对应的字母填充到相应的输入框中
// 4 上下左右
// ++ 后期扩展，从光标位置删除输入的内容，长按删除，逐个删除输入内容

// 1 特定按键，唤醒虚拟键盘
class keyBody {
	constructor(config) {
		const {
			keyListLowercase,
			keyListUppercase,
			keyBox,
			action,
			inputWrap
		} = { ...config
		}
		// 1 定义虚拟键盘格式，并布局 lowercase uppercase
		const KEY_CONFIG_INIT_LOWERCASE = [
			[0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
			["q", "w", "e", "r", "t", "y", "u", "i", "o", "p"],
			["a", "s", "d", "f", "g", "h", "j", "k", "l"],
			["z", "x", "c", "v", "b", "n", "m"],
		];
		const KEY_CONFIG_INIT_UPPERCASE = [
			[0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
			["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
			["A", "S", "D", "F", "G", "H", "J", "K", "L"],
			["Z", "X", "C", "V", "B", "N", "M"]
		];
		this.version = "1.0.0";
		this.describe = "Rely on the jq";
		this.time = "2020-09-14";
		this.keyListLowercase = keyListLowercase || KEY_CONFIG_INIT_LOWERCASE;
		this.keyListUppercase = keyListUppercase || KEY_CONFIG_INIT_UPPERCASE;
		this.keyArray = [];
		this.action = action || "0_0";
		this.inputWrap = inputWrap;
		this.keyBox = keyBox;
		this.isLowercase = true;
		this.verify()
		this.init(this.keyListLowercase);
		this.keyChange()
	}
	init(data) {
		// 初始化键盘
		this.keyArray = data
		$(`${this.keyBox}`).html("")
		let child = '';
		const html =
			`
						<div id="keyBox"></div>
					`
		$(`${this.keyBox}`).html(html);
		data.map((item, indexF) => {
			child += `<table border="0"><tr>`
			data[indexF].map((item, index) => {
				let action = `${indexF}_${index}`
				child +=
					`<td ><input data-type="${action}" class="${action} ${this.action==action?'action':''}" type="button" value="${item}"/></td>`
			})
			child += `</tr></table>`
		})
		$("#keyBox").html(child);
		this.click()
		return this;
	}
	verify() {
		if (!this.keyBox) {
			this.error("keyBox is undefined")
		}
		if (!this.inputWrap) {
			this.error("inputWrap is undefined")
		}
	}
	focus(focus) {
		this.inputWrap = focus
	}
	error(msg) {
		throw new Error(msg);
	}
	inputValue(data) {
		console.log("光标位置",this.getCursortPosition())
		if (this.isHidden()) return;
		$(`${this.inputWrap}`).val($(`${this.inputWrap}`).val() + data)
	}
	click() {
		let that = this;
		$("#keyBox input").click(function() {
			that.inputValue($(this).val())
			that.autoAction($(this).attr("data-type"))
		})
	}
	keyChange() {
		$(document).keydown((e) => {
			e.stopPropagation()
			let keyCode = e.keyCode || e.which || e.charCode
			if (this.isHidden()) return;
			if (keyCode == 12||keyCode==33) {
				e.preventDefault()
				this.changeLowerOrUpper()
			} else if (keyCode == 38) {
				e.preventDefault()
				this.direction("up")
			} else if (keyCode == 40) {
				e.preventDefault()
				this.direction("down")
			} else if (keyCode == 37) {
				e.preventDefault()
				this.direction("left")
			} else if (keyCode == 39) {
				e.preventDefault()
				this.direction("right")
			} else if (keyCode == 13) {
				this.inputValue($(`.${this.action}`).val())
			}
		})
	}
	changeLowerOrUpper() {
		this.isLowercase = !this.isLowercase;
		this.isLowercase ? this.init(this.keyListLowercase) : this.init(this.keyListUppercase)
	}
	direction(type) {
		let actionType = this.action.split("_");
		let keyArray = this.keyArray;
		let x = Number(actionType[0]),
			y = Number(actionType[1]);
		switch (type) {
			case "up":
				x -= 1;
				break;
			case "down":
				x += 1;
				break;
			case "left":
				y -= 1;
				break;
			case "right":
				y += 1;
				break;
		}
		if (x <= 0) {
			x = 0;
		} else if (x >= keyArray.length - 1) {
			x = keyArray.length - 1
		}
		if (y <= 0) {
			y = 0
		} else if (y >= keyArray[x].length - 1) {
			y = keyArray[x].length - 1
		}
		this.autoAction(`${x}_${y}`)
	}
	getCursortPosition() {
		let cursorIndex = 0;
		let obj = $(`${this.inputWrap}`)
		if (document.selection) {
			// IE Support
			obj.focus();
			var range = document.selection.createRange();
			range.moveStart('character', -obj.value.length);
			cursorIndex = range.text.length;
		} else if (obj.selectionStart || obj.selectionStart == 0) {
			// another support
			cursorIndex = obj.selectionStart;
		}
		return cursorIndex;
	}
	autoAction(type) {
		this.action = type;
		$("#keyBox input").each((index, item) => {
			$(item).removeClass("action")
		})
		$(`.${type}`).addClass("action")
	}
	hide() {
		$(`${this.keyBox}`).fadeOut(300);
		return this;
	}
	show() {
		$(`${this.keyBox}`).fadeIn(300);
		return this;
	}
	isHidden() {
		return $(`${this.keyBox}`).is(":hidden")
	}
}
