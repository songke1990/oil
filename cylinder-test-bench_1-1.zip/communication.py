"""
通信文件
"""
import Pyro5.api
import Pyro5.errors
from pi_exception import *
from strategy import pyro5_ip
import time

# 初始化建立连接
pyro_object = Pyro5.api.Proxy(pyro5_ip)
Pyro5.config.COMMTIMEOUT = 1


class Communication:
    @classmethod
    def action(cls, action_code, switch, pyro=pyro_object):
        global pyro_object
        """
        控制动作函数
        :param action_code: 动作码
        :param switch: 开关 开关 0关 1开
        :return:
        """
        try:
            pyro.do_config(action_code, switch)
        except Pyro5.errors.ConnectionClosedError:
            pyro._pyroReconnect(3)
            raise ConnectionFailException("远程连接失败")
        except Pyro5.errors.CommunicationError:
            raise ConnectionFailException("通信连接未建立")
        else:
            return

    @classmethod
    def data(cls, data_type, data_code, pyro=pyro_object):
        global pyro_object
        """
        获取数据函数
        :param data_type: 1为电压 2为电流
        :param data_code: 传感器数据码
        :return: 对应数据
        """
        try:
            data = pyro.ai_data(data_type, data_code)
        except Pyro5.errors.ConnectionClosedError:
            pyro._pyroReconnect(3)
            raise ConnectionFailException("远程连接失败")
        except Pyro5.errors.CommunicationError:
            raise ConnectionFailException("通信连接未建立")
        else:
            return data

    @classmethod
    def switching_value(cls, switch_code, pyro=pyro_object):
        global pyro_object
        """
        开关量接受
        :param switch_code: 开关code
        :return: 对应开关量 1为开启 0为关闭
        """
        try:
            value = pyro.di_switching_value(switch_code)
        except Pyro5.errors.ConnectionClosedError:
            pyro._pyroReconnect(3)
            raise ConnectionFailException("远程连接失败")
        except Pyro5.errors.CommunicationError:
            raise ConnectionFailException("通信连接未建立")
        else:
            return value
if __name__ == '__main__':
    com=Communication()
    # com.action(0, 1)
    # time.sleep(0.03)
    # com.action(0, 0)

    # a1=com.switching_value(1)
    # print(a1)
    # time.sleep(1)
    # a2=com.switching_value(0)
    # print(a2)

    # for i in range(0,16):
    #     ai=com.data(1,i)
    #     print(i,ai)