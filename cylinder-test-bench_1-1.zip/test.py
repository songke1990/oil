# -*- coding:utf-8 -*-
# @Time  : 2021/7/30 11:55
# @Author: SGK
# @File  : test.py
import os
import json
data = {"errorMessage": '45662', "testNo": '1627606628.8475103'}
if data["testNo"] in os.listdir("./data"):
    record_dir = "./data/{}".format(data["testNo"])
    with open(record_dir + "/data.json",'r+') as fp:
        j=json.load(fp)
        j["errorMessage"] = data["errorMessage"]
        print(j)
    with open(record_dir + "/data.json", "w+") as fp:
        fp.write(json.dumps(j))


data={'NULL':'326','2':'6969'}
print(data.keys())
if 'NULL' in data.keys():
    print('pppp')