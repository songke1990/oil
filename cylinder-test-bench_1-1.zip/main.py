import sys
from PyQt5.QtCore import pyqtSlot, QObject, QUrl
from PyQt5 import QtGui
from PyQt5.QtWebChannel import QWebChannel
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWidgets import QMainWindow, QApplication
from schedule import Schedule
from flow import Flow, json, q, Remote, get_config
from config.config import *


class CallHandler(QObject):
    """
        CallHandler
        用于和 html数据通信的函数
    """

    # 电压型 有位移
    @pyqtSlot(str, result=str)
    def start(self, start_data):
        Flow(json.loads(start_data)).start()
        return "电压型 有位移开始实验"

    # 电流型 有位移
    @pyqtSlot(str, result=str)
    def electricity_start(self, start_data):
        Flow(json.loads(start_data)).electricity_start()
        return "电流型 有位移开始实验"

    # 无行程
    @pyqtSlot(str, result=str)
    def no_displacement_start(self, start_data):
        Flow(json.loads(start_data)).no_displacement_start()
        return "无行程开始实验"

    # 图表数据
    @pyqtSlot(str, result=str)
    def get_data(self):
        if q.empty():
            return ''
        return q.get()

    @pyqtSlot(str, result=str)
    def post_fault(self, data):
        data = json.loads(data)
        Remote.stop_info(data["record_no"], data["error_message"])
        return "故障原因"

    # 获取配置
    @pyqtSlot(str, result=str)
    def get_config_pyqt(self, data):
        displacement_offset, depressurization_scope, journey_time, pressure_time, pressure_keep, stretched_num, \
            pressure_middle = get_config()
        config_data = {
            'displacement_offset': displacement_offset,
            'depressurization_scope': depressurization_scope,
            'journey_time': journey_time,
            'pressure_time': pressure_time,
            'pressure_keep': pressure_keep,
            'stretched_num': stretched_num,
            'pressure_middle': pressure_middle
        }
        return json.dumps(config_data)

    # 修改配置
    @pyqtSlot(str, result=str)
    def change_config(self, data):
        Config().set_config(json.loads(data), change_config_callback)
        return '修改成功'

    @pyqtSlot(str, result=str)
    def printPy(self, data):
        print(json.loads(data))
        return "日志"


def change_config_callback():
    get_config()


class MainWindow(QMainWindow):
    """
        MainWindow
        用于生成pyQt5，引入html文件
    """

    def __init__(self):
        super(MainWindow, self).__init__()
        self.setWindowTitle('郑煤机推移千斤顶综合测试平台')
        desktop = QApplication.desktop()
        self.resize(1920, 1080)
        # setFixedSize 禁止缩放
        #self.setFixedSize(desktop.width(), desktop.height())
        self.move(0, 0)
        self.browser = QWebEngineView()
        self.browser.load(QUrl("file:///./html/index.html"))
        self.setCentralWidget(self.browser)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("title_icon.ico"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.setWindowIcon(icon)

        # WindowStaysOnTopHint 覆盖状态栏 WindowMinimizeButtonHint 显示最小化 WindowCloseButtonHint 显示关闭 FramelessWindowHint 隐藏界面整个头部内容 MSWindowsFixedSizeDialogHint 禁止缩放
		# self.setWindowFlags(Qt.FramelessWindowHint) Qt.WindowMinimizeButtonHint
        # self.setWindowFlags(Qt.WindowStaysOnTopHint | Qt.WindowCloseButtonHint | Qt.WindowCloseButtonHint | Qt.MSWindowsFixedSizeDialogHint)
        # self.setWindowFlags(Qt.FramelessWindowHint)

    def closeEvent(self):
        sys.exit(app.exec_())

    def mouseMoveEvent(self, QMouseEvent):
        self.move()  # 更改窗口位置
        QMouseEvent.accept()


if __name__ == '__main__':
    # 启动定时任务
    schedule_object = Schedule()
    schedule_object.run()
    app = QApplication(sys.argv)
    win = MainWindow()
    channel = QWebChannel()
    handler = CallHandler()
    channel.registerObject("pyjs", handler)
    win.browser.page().setWebChannel(channel)
    # QCoreApplication.setAttribute(Qt.AA_EnableHighDpiScaling)
    win.show()
    sys.exit(app.exec_())
