"""
策略文件
"""
from psutil import net_if_addrs

"""
    常量
"""

# 数据次数
str1 = "活塞腔实际保压压力"
str2 = "2/3活塞杆腔实际保压压力"
str3 = "活塞杆腔实际保压压力"

# 时间判断超时时间
displacement_judgment_time = 120
# 压力判断超时时间
pression_judgment_time = 50
# 极限位置系统压力与腔内压力差绝对值
system_pre_diff_abs = 0.5
# 极限位置达到差值范围内次数
system_pre_diff_num = 3
# 上腔压力增速压力差
up_pre_diff = 15
# 下腔压力增速压力差
down_pre_diff = 10
# 增压压力差
add_pre_diff = 1
# 允许最大压力
pre_max = 50
# 大小缸
oil_size = {
    "oil_small": {
        "fast_interval": 0.1,
        "slow_interval": 0.08
    },
    "oil_large": {
        "fast_interval": 0.3,
        "slow_interval": 0.15
    }
}
# pyro5 ip
#pyro5_ip = "PYRO:pyro.moxa@192.168.127.254:7777"
pyro5_ip = "PYRO:pyro.moxa@192.168.3.16:7777"
# mac地址list
mac_list = []
# 服务器url
#url = "cylinder.biz.zhengmeiji.com.cn"
# 端口
#port = "81"
# 获取mac地址
for k, v in net_if_addrs().items():
    for item in v:
        address = item[1]
        if len(address) == 17:
            if '-' in address:
                adress=address.replace('-', ':')
            mac_list.append(adress.lower())
print(mac_list)