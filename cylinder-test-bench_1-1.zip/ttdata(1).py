# -*- coding:utf-8 -*-
# @Time  : 2021/6/7 14:43
# @Author: SGK
# @File  : ttdata.py

import json
import os
import shutil
import requests

def send_data():
    for test_dir in os.listdir("./data"):
        record_dir = "./data/{}".format(test_dir)
        test_file_list = filter(lambda x: x != "data.json", os.listdir(record_dir))
        if os.path.getsize(record_dir + "/data.json") == 0:
            shutil.rmtree(record_dir)
            continue
        if 'NULL' in json.load(open(record_dir + "/data.json")).keys():
            print(json.load(open(record_dir + "/data.json")).keys())
            # shutil.rmtree(record_dir)
            # continue

        # with open(record_dir + "/data.json") as fp:
        #     record_data = json.load(fp)
        # files = [("files", (i, open(record_dir + "/" + i, "rb"))) for i in test_file_list]
        # try:
        #     re = requests.post("https://router-test.zmjkf.cn/api/cylinder/" + "cylinder/api/v1/cylinderPlatform/add",
        #                        headers={"Content-Type": "application/json"}, data=json.dumps(record_data))
        # except Exception as e:
        #     print(e)
        #     for i in files:
        #         print(i[1][1])
        #         i[1][1].close()
        # else:
        #     for i in files:
        #         print(i[1][1])
        #         i[1][1].close()
        #     shutil.rmtree(record_dir)

def send_data1(dress):
    data = {
        "constructionNo": "123456",
        "macAddressList": [
            "74:df:bf:0a:3b:48", "dc:a6:32:15:06:34"
        ],
        "oilCylinderType": 1,
        "productNo": "string",
        "recordNo": "123456",
        "testData": json.dumps([{"realLength": 200, "upPre": 100, "downPre": 50, "currentTime": 2},
                     {"realLength": 200, "upPre": 100, "downPre": 50, "currentTime": 2}]),
        "testTime": "2021-06-02 07:35:46",
        "testType": 0,
        "userNo": "string",
    }
    print(json.dumps(data))
    headers = {"Content-Type": "application/json"}
    response = requests.post(dress + "/cylinder/api/v1/cylinderPlatform/add", headers=headers,
                             data=json.dumps(data))

    print(response.text)
    print(response.status_code)

if __name__ == "__main__":
    #url1 = "http://cylinder.biz.zhengmeiji.com.cn:81"
    #send_data1(url1)
    send_data()
