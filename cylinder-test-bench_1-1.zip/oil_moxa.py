from ioThinx_4530 import ioThinx_4530_API
from Pyro5.api import expose, Daemon
import Pyro5.server

# Moxa参数
AI_RANGE_4_20mA_BURNOUT = 1
AI_RANGE_4_20mA_BURNOUT_ELE = 2

do_slot = 2
# do_channel = 1
do_count = 1
do_mode = [0] * do_count

ai_slot = 1
ai_slot_electricity = 4
ai_channel_start = 0
ai_channel_count = 5

di_slot = 3
di_channel = 0
di_count = 1
di_filter = [2]

# 初始化Moxa
device = ioThinx_4530_API.ioThinx_4530_API()

device.ioThinx_DO_Config_SetModes(do_slot, 0, do_count, do_mode)  # 上腔液控
device.ioThinx_DO_Config_SetModes(do_slot, 1, do_count, do_mode)  # 下腔液控
device.ioThinx_DO_Config_SetModes(do_slot, 2, do_count, do_mode)  # 上腔锁
device.ioThinx_DO_Config_SetModes(do_slot, 3, do_count, do_mode)  # 下腔锁
device.ioThinx_DO_Config_SetModes(do_slot, 4, do_count, do_mode)  # 充液
device.ioThinx_DO_Config_SetModes(do_slot, 5, do_count, do_mode)  # 卸载
device.ioThinx_DO_Config_SetModes(do_slot, 6, do_count, do_mode)  # 增压1
device.ioThinx_DO_Config_SetModes(do_slot, 7, do_count, do_mode)  # 增压2
device.ioThinx_DO_Config_SetModes(do_slot, 8, do_count, do_mode)  # 减速

device.ioThinx_DI_Config_SetFilters(di_slot, di_channel, di_count, di_filter)

ai_ranges = [AI_RANGE_4_20mA_BURNOUT] * ai_channel_count
device.ioThinx_AI_Config_SetRanges(ai_slot, ai_channel_start, ai_channel_count, ai_ranges)
ai_burnouts = [2.0] * ai_channel_count
device.ioThinx_AI_Config_SetBurnoutValues(ai_slot, ai_channel_start, ai_channel_count, ai_burnouts)

ai_ranges_electricity = [AI_RANGE_4_20mA_BURNOUT_ELE] * ai_channel_count
device.ioThinx_AI_Config_SetRanges(ai_slot_electricity, ai_channel_start, ai_channel_count, ai_ranges_electricity)
ai_burnouts_electricity = [2.0] * ai_channel_count
device.ioThinx_AI_Config_SetBurnoutValues(ai_slot_electricity, ai_channel_start, ai_channel_count,
                                          ai_burnouts_electricity)

device.ioThinx_IO_Config_Reload()
do_values = device.ioThinx_DO_GetValues(do_slot)


# 配置pyro5
@expose
class Moxa(object):
    def do_config(self, action_code, switch):
        """
        控制动作函数
        :param action_code: 动作码
        :param switch: 开关 0关 1开
        :return:
        """
        do_values[action_code] = switch
        device.ioThinx_DO_SetValues(do_slot, do_values)

    def ai_data(self, data_type, data_code):
        """
        获取数据函数
        :param data_type: 1为电压 2为电流
        :param data_code: 传感器数据码
        :return: 对应数据
        """
        if data_type == 1:
            data = device.ioThinx_AI_GetEngs(ai_slot, ai_channel_start, ai_channel_count)
        elif data_type == 2:
            data = device.ioThinx_AI_GetEngs(ai_slot_electricity, ai_channel_start, ai_channel_count)
        else:
            return None
        return data[data_code]

    def di_switching_value(self, switch_code):
        """
        开关量接受
        :param switch_code: 开关code
        :return: 对应开关量 1为开启 0为关闭
        """
        di_values = device.ioThinx_DI_GetValues(di_slot)
        return di_values[switch_code]


# 初始化pyro并启动服务
with Daemon(port=7777, host="0.0.0.0") as daemon:
    uri = daemon.register(Moxa, objectId="pyro.moxa")
    print("start")
    daemon.requestLoop()
