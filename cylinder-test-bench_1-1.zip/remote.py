import csv
import json
import os
import shutil
import time
from os import path

import requests
from strategy import *
from pi_logging import logger

class Remote(object):
    def __init__(self, json_str):
        data_dict = json.loads(json_str)
        # 获取json信息
        # 用户编号
        self.user_no = data_dict["user_no"]
        # 施工编号
        self.construction_no = data_dict["construction_no"]
        # 产品编号
        self.product_no = data_dict["product_no"]
        # 测试时间
        self.test_time = time.time()
        # 错误编码
        self.error_code = data_dict["code"]
        # 错误信息
        self.error_message = data_dict["message"]
        # 测试记录唯一值
        self.test_num = data_dict["data"]["num"]
        # 数据列表
        self.figure_data = data_dict["data"]["dataList"]
        # 压力表列表
        self.pre_table = data_dict["data"]["preList"]
        # 位移表列表
        self.displacement_table = data_dict["data"]["displacementList"]
        # 油缸类型
        self.oil_cylinder_type = int(data_dict["oil_cylinder_type"])
        # 测试类型
        self.test_type = None
        # 油缸长度
        self.oilcylinder_length = None
        if self.oil_cylinder_type == 1:
            # 测试类型
            self.test_type = int(data_dict["test_type"])
            # 油缸长度
            self.oilcylinder_length = data_dict["oilcylinder_length"]
            self.data = {'macAddressList': mac_list, 'userNo': self.user_no, 'productNo': self.product_no,
                         'oilCylinderLength': int(self.oilcylinder_length),
                         'testTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
                         'oilCylinderType': self.oil_cylinder_type, 'testType': self.test_type,
                         'constructionNo': self.construction_no,
                         'recordNo': self.test_num,
                         'testData': json.dumps(self.figure_data)}
            if self.displacement_table:
                self.data['displacementData'] = json.dumps(self.displacement_table)
            if self.pre_table:
                self.data['pressureData'] = json.dumps(self.pre_table)

        else:
            self.data = {'macAddressList': mac_list, 'userNo': self.user_no, 'productNo': self.product_no,
                         'testTime': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
                         'oilCylinderType': self.oil_cylinder_type, 'constructionNo': self.construction_no,
                         "recordNo": self.test_num, 'testData': json.dumps(self.figure_data)}
            if self.pre_table:
                self.data['pressureData'] = json.dumps(self.pre_table)

    @classmethod
    def csv_load(cls, data_dir, rows):
        with open(data_dir, 'w', newline='', encoding="utf-8") as fp:
            writer = csv.writer(fp)
            rows = rows
            writer.writerows(rows)

    def displacement_table_operate(self, file_dir):
        displacement_rows = [
            [row["measureValue"], [row["actualValueMax"]], row["actualValue"], row["deviationValue"], row["boolValue"]]
            for row in self.displacement_table]
        self.csv_load(file_dir + "/displacementData.csv", displacement_rows)

    def pre_table_operate(self, file_dir):
        pre_rows = [
            [row["preInfo"], row["preValue"], row["preTime"], row["preDropFirst"], row["preDrop"], row["boolValue"]]
            for row in self.pre_table]
        self.csv_load(file_dir + "/preData.csv", pre_rows)

    def figure_data_operate(self, file_dir):
        figure_rows = [[row["upPre"], row["downPre"], row["currentTime"]] for row in
                       self.figure_data]
        self.csv_load(file_dir + "/figureData.csv", figure_rows)

    def create_dir(self):
        if not path.exists("./data/{}".format(self.test_num)):
            os.mkdir("./data/{}".format(self.test_num))
        return "./data/{}".format(self.test_num)

    def save_test_data(self, data_dir):
        with open(data_dir + "/data.json", "w") as fp:
            json.dump(self.data, fp)

    @staticmethod
    def send_data():
        for test_dir in os.listdir("./data"):
            record_dir = "./data/{}".format(test_dir)
            test_file_list = filter(lambda x: x != "data.json", os.listdir(record_dir))
            if os.path.getsize(record_dir + "/data.json") == 0 :
                shutil.rmtree(record_dir)
                continue
            with open(record_dir + "/data.json") as fp:
                record_data = json.load(fp)
            files = [("files", (i, open(record_dir + "/" + i, "rb"))) for i in test_file_list]
            try:
                re = requests.post("https://router-test.zmjkf.cn/api/cylinder/" + "cylinder/api/v1/cylinderPlatform/add",
                              headers={"Content-Type": "application/json"}, data=json.dumps(record_data))

                # re = requests.post("http://" + url + ":" + port + "/cylinder/api/v1/cylinderPlatform/add",
                #               headers={"Content-Type": "application/json"},data=record_data)
                print(re.text)
                print(re.status_code)
            except Exception as e:
                print(e)
                for i in files:
                    print(i[1][1])
                    i[1][1].close()
            else:
                for i in files:
                    print(i[1][1])
                    i[1][1].close()
                shutil.rmtree(record_dir)

    def transmit_data(self):
        # 生成本次实验目录
        data_dir = self.create_dir()
        if self.error_code == 1:
            # 成功创建目录存csv然后存数据库
            # 获取json data数据
            # 生成位移图数据csv
            if self.oil_cylinder_type == 1:
                self.displacement_table_operate(data_dir)
            # 生成压力表数据csv
            self.pre_table_operate(data_dir)
            # 生成折线图数据csv
            self.figure_data_operate(data_dir)
            logger.info("试验成功：：：：：：：：")
        else:
            # 实验失败情况
            if self.displacement_table:
                self.displacement_table_operate(data_dir)
            if self.pre_table:
                self.pre_table_operate(data_dir)
            if self.figure_data:
                self.figure_data_operate(data_dir)
            # 失败直接存数据库
            logger.info("实验失败：：：：：：：：")
            self.data["errorCode"] = self.error_code
            self.data["errorMessage"] = self.error_message
        # 测试数据信息存入json文件
        self.save_test_data(data_dir)
        # 文件传输包括补传
        self.send_data()
        logger.info("数据传输完成：：：：：：：：")

    @staticmethod
    def stop_info(record_no, error_message):
        print('急停*******************&&&&&&&*')
        # data = {"errorMessage": error_message, "testNo": record_no}
        # if data["testNo"] in os.listdir("./data"):
        #     record_dir = "./data/{}".format(data["testNo"])
        #     with open(record_dir + "/data.json","r+") as fp:
        #         record_data = json.load(fp)
        #         record_data["errorMessage"] = data["errorMessage"]
        #     with open(record_dir + "/data.json", "w+") as fp:
        #         fp.write(json.dumps(record_data))
        # else:
        #     requests.post("https://router-test.zmjkf.cn/api/cylinder/" + "cylinder/api/v1/cylinderPlatform/update",
        #                   headers={'Content-Type': 'application/json'}, data=json.dumps(data))
        #
        #     # requests.post("http://" + url + ":" + port + "/cylinder/api/v1/cylinderPlatform/update",
        #     #                          headers={'Content-Type': 'application/json'}, data=json.dumps(data))
        #     logger.info("急停数据数据传输{}：：：：：：：：".format(data))
