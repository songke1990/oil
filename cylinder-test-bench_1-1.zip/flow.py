from multiprocessing import Queue
from threading import Thread

from communication import *
from remote import *
from pi_logging import logger
from config.config import *

"""
    变化值
"""
# 油缸长度
oil_length = 0
# 压力快速增压时间间隔
fast_pressurize_time_interval = 0.5
# 压力慢速增压时间间隔
slow_pressurize_time_interval = 0.2
# 队列
q = Queue()
# 状态码
code = None
# 状态说明
message = ""
# 远程状态码
remote_code = 0
# 远程说明
remote_message = ""
# 是否实验中
is_test = 0
# 单个位移表格数据
displacement_dict = {}
# 单个压力表格数据
pre_dict = {}
# 整个实验位移表格数据
displacement_list = []
# 整个实验压力表格数据
pre_list = []
# 是否带位移
displacement_exist = 0
# 实验类型1：电压2：电流
test_type = 1
# 实验过程中所有折线图数据list
data_list = []
# 放入队列json格式
queue_dict = {}
# 数据字典
data_dict = {}
# 时间
num = 0
# 远程数据参数
remote_dict = {}
# 实验唯一值
test_num = 0
# 油缸类型
oil_cylinder_type = 0

#配置文件参数设置
"""
displacement_offset:                位移允许偏差    h
depressurization_scope:             降压范围        q
pressure_keep:                      保压压力        p
journey_time:                       行程稳定时长    t1
pressure_time:                      保压稳态时长    t2
stretched_num:                      伸出次数        stretched_num
pression_middle:                    中间保压        gender
"""

displacement_offset = 0
depressurization_scope = 0
journey_time = 0
pressure_time = 0
pressure_keep = 0
stretched_num = 0
pressure_middle = 0

def get_config():
    global displacement_offset, depressurization_scope, journey_time, pressure_time, pressure_keep, stretched_num, \
        pressure_middle
    config = Config()
    displacement_offset, depressurization_scope, journey_time, pressure_time, pressure_keep, stretched_num, \
        pressure_middle = config.get_conf()
    return displacement_offset, depressurization_scope, journey_time, pressure_time, pressure_keep, stretched_num, \
        pressure_middle

get_config()

class Flow(object):

    def __init__(self, param_data):
        self.param_data = param_data
        self.pyro_object = None
        logger.info("前端入参{}：：：：：：：：：".format(param_data))

    @classmethod
    def data_convert(cls, data_type, data):
        """
        传感器数据转换
        :param data_type: 0:压力 1:电压位移 2:电流位移
        :param data: 原始传感器数据
        :return: 转换后数据
        """
        data = float(data)
        if oil_length == 0:
            oil_length_fun = 960
        else:
            oil_length_fun = oil_length
        if data_type == 0:
            data = (data - 0.5) * 15
        elif data_type == 1:
            data = (data - 0.5) * (oil_length_fun / 4)
        elif data_type == 2:
            data = (data - 4) * (oil_length_fun / 16)
        else:
            pass
        return data

    def displace_time(self, a1, a2, t=0):
        """
            时间判断函数，判断是否在时间内位移变成正确范围或时间超时
        :param a1: 位移量标准左临界
        :param a2: 位移量标准右临界
        :param t: 时间控制
        :return:
        """
        # 5s循环，判断位移量是否符合标准
        while t <= displacement_judgment_time:
            if not is_test:
                # myapp.error("检测stop为true停止实验")
                return "stop"
            #  位移来自传感器
            if test_type == 1:
                displacement = self.data_convert(1, Communication.data(1, 0, self.pyro_object))
            else:
                displacement = self.data_convert(2, Communication.data(2, 0, self.pyro_object))

            if a1 < displacement < a2:
                break
            time.sleep(0.05)
            t += 0.05
        if t > displacement_judgment_time:
            return True
        else:
            return False

    @classmethod
    def supercharged_dormancy_strategy(cls, mode, a, pression, t):
        """
        增压休眠策略
        :param mode: 0上腔压1下腔压
        :param a: 压力最高值
        :param pression: 当前压力
        :param t: 当前时间
        :return:
        """
        if mode == 1:
            if a - pression < down_pre_diff:
                time.sleep(slow_pressurize_time_interval)
                t += slow_pressurize_time_interval
            else:
                time.sleep(fast_pressurize_time_interval)
                t += fast_pressurize_time_interval
        else:
            if a - pression < up_pre_diff:
                time.sleep(slow_pressurize_time_interval)
                t += slow_pressurize_time_interval
            else:
                time.sleep(fast_pressurize_time_interval)
                t += fast_pressurize_time_interval
        return t

    def pression_time(self, a, mode, t=0):
        """
        压力时间判断函数，判断是否在时间内压力变成正确范围或时间超时
        :param a: 压力范围
        :param mode: 0 上腔压力 其他为下腔压力
        :param t: 时间控制
        :return:
        """
        pre_num = 0
        while t <= pression_judgment_time:
            if not is_test:
                # myapp.error("检测stop为true停止实验")
                return "stop"
            # 压力数据
            if mode == 0:
                pression = self.data_convert(0, Communication.data(1, 1, self.pyro_object))
            else:
                pression = self.data_convert(0, Communication.data(1, 2, self.pyro_object))
            if pression > pre_max:
                return "error"
            if pression > a:
                break
            else:
                if pre_num % 2 == 0:
                    Communication.action(6, 1, self.pyro_object)  # 加压1开启
                    t = self.supercharged_dormancy_strategy(mode, a, pression, t)
                    Communication.action(6, 0, self.pyro_object)  # 加压1关闭
                    time.sleep(0.3)
                    t += 0.3
                else:
                    Communication.action(7, 1, self.pyro_object)  # 加压2开启
                    t = self.supercharged_dormancy_strategy(mode, a, pression, t)
                    Communication.action(7, 0, self.pyro_object)  # 加压2关闭
                    time.sleep(0.3)
                    t += 0.3
                if mode == 0:
                    pre_diff = self.data_convert(0, Communication.data(1, 1, self.pyro_object)) - pression
                else:
                    pre_diff = self.data_convert(0, Communication.data(1, 2, self.pyro_object)) - pression
                # 增压压力小于1
                if pre_diff < add_pre_diff:
                    pre_num += 1
            time.sleep(0.05)
            t += 0.05
        if t > pression_judgment_time:
            return True
        else:
            return False

    def displace_law(self, t1, t=0):
        """
            位移差函数
        :param t1: 行程稳态时长
        :param t: 时间控制
        :return:
        """
        global displacement_dict
        displacement_max_min = []
        while True:
            if not is_test:
                # myapp.error("检测stop为true停止实验")
                return "stop"
            if test_type == 1:
                displacement = self.data_convert(1, Communication.data(1, 0, self.pyro_object))
            else:
                displacement = self.data_convert(2, Communication.data(2, 0, self.pyro_object))
            if t > 2:
                displacement_max_min.append(displacement)
            time.sleep(0.5)
            t += 0.5
            if t > t1:
                displacement_max_min.sort()
                diff = displacement_max_min[-1] - displacement_max_min[0]
                displacement_list.append({"actualValueMax": round(displacement_max_min[-1], 2),
                                          "actualValue": round(displacement_max_min[0], 2),
                                          "deviationValue": round(diff, 2),
                                          "boolValue": diff < displacement_offset})
                displacement_dict = {"actual_value_max": round(displacement_max_min[-1], 2),
                                     "actual_value": round(displacement_max_min[0], 2),
                                     "deviation_value": round(diff, 2),
                                     "bool_value": diff < displacement_offset}
                return diff

    def pression_law(self, t2, mode, table_str, t=0):
        """
        保压
        :param t2: 保压稳态时长
        :param mode: 0 上腔压 其他下腔
        :param table_str: 当前保压阶段说明
        :param t: 时间控制
        :return:
        """
        global displacement_dict, pre_dict
        pression_max_min = []
        displacement_max_min = []
        pre_diff_first_bool = True
        pre_diff_first = 0
        while True:
            if not is_test:
                return "stop"
            if mode == 0:
                pression = self.data_convert(0, Communication.data(1, 1, self.pyro_object))
            else:
                pression = self.data_convert(0, Communication.data(1, 2, self.pyro_object))
            if test_type == 1:
                displacement = self.data_convert(1, Communication.data(1, 0, self.pyro_object))
            else:
                displacement = self.data_convert(2, Communication.data(2, 0, self.pyro_object))
            if t > 2:
                pression_max_min.append(pression)
                displacement_max_min.append(displacement)
                if t == 60:
                    pression_max_min.sort()
                    pre_diff_first = pression_max_min[-1] - pression_max_min[0]
                    pre_diff_first_bool = pre_diff_first < pressure_keep * 0.1
                    pression_max_min.clear()
            if t > t2:
                pression_max_min.sort()
                displacement_max_min.sort()
                diff1 = displacement_max_min[-1] - displacement_max_min[0]
                pre_diff_second = pression_max_min[-1] - pression_max_min[0]
                pre_diff_second_bool = pre_diff_second < depressurization_scope
                diff2 = pre_diff_second
                pre_bool = pre_diff_second_bool and pre_diff_first_bool
                displacement_list.append({"actualValueMax": round(displacement_max_min[-1], 2),
                                          "actualValue": round(displacement_max_min[0], 2),
                                          "deviationValue": round(diff1, 2),
                                          "boolValue": diff1 < displacement_offset})
                pre_list.append({"preInfo": table_str, "preValue": round(pression_max_min[-1], 2), "preTime": t2,
                                 "preDropFirst": round(pre_diff_first, 2),
                                 "preDrop": round(diff2, 2), "boolValue": pre_bool})
                displacement_dict = {"actual_value_max": round(displacement_max_min[-1], 2),
                                     "actual_value": round(displacement_max_min[0], 2),
                                     "deviation_value": round(diff1, 2),
                                     "bool_value": diff1 < displacement_offset}
                pre_dict = {"pre_info": table_str, "pre_value": round(pression_max_min[-1], 2), "pre_time": t2,
                            "pre_drop_first": round(pre_diff_first, 2), "pre_drop": round(diff2, 2),
                            "bool_value": pre_bool}
                return diff2
            time.sleep(0.5)
            t += 0.5

    def no_displacement_judge(self, mode, t=0):
        """
        无位移缸判断位移
        :param mode: 0上腔压1下腔压
        :param t:
        :return:
        """
        n = 0
        while t <= displacement_judgment_time:
            if not is_test:
                return "stop"
            if mode == 0:
                pression = self.data_convert(0, Communication.data(1, 1, self.pyro_object))
            else:
                pression = self.data_convert(0, Communication.data(1, 2, self.pyro_object))
            system_pre = self.data_convert(0, Communication.data(1, 3, self.pyro_object))
            if system_pre - pression < system_pre_diff_abs:
                n += 1
            else:
                n = 0
            if n >= system_pre_diff_num:
                break
            time.sleep(0.05)
            t += 0.05
        if t > displacement_judgment_time:
            return True
        else:
            return False

    def init_check(self):
        """
        校验初始化是否成功
        :return:
        """
        up_pre = self.data_convert(0, Communication.data(1, 1, self.pyro_object))
        down_pre = self.data_convert(0, Communication.data(1, 2, self.pyro_object))
        if up_pre > 5 or down_pre > 5:
            self.stop_init()
            up_pre = self.data_convert(0, Communication.data(1, 1, self.pyro_object))
            down_pre = self.data_convert(0, Communication.data(1, 2, self.pyro_object))
            if up_pre > 5 or down_pre > 5:
                return True
        return False

    def stop_init(self):
        """
        全部关闭
        Communication().action(动作码, 开关)
        关 0开 1关
        :return:
        """
        Communication.action(0, 0, self.pyro_object)  # 上腔停液
        Communication.action(1, 0, self.pyro_object)  # 下腔停液
        Communication.action(2, 0, self.pyro_object)  # 上腔锁关闭
        Communication.action(3, 0, self.pyro_object)  # 下腔锁关闭
        Communication.action(4, 0, self.pyro_object)  # 充液
        Communication.action(5, 0, self.pyro_object)  # 卸载
        Communication.action(6, 0, self.pyro_object)  # 加压1
        Communication.action(7, 0, self.pyro_object)  # 加压2
        Communication.action(8, 0, self.pyro_object)  # 减速

        # 泄压
        Communication.action(2, 1, self.pyro_object)  # 上腔锁打开
        Communication.action(3, 1, self.pyro_object)  # 下腔锁打开
        Communication.action(5, 1, self.pyro_object)  # 卸载打开

        time.sleep(3)

        Communication.action(2, 0, self.pyro_object)  # 上腔锁打开
        Communication.action(3, 0, self.pyro_object)  # 下腔锁打开
        Communication.action(5, 0, self.pyro_object)  # 卸载打开

    def data_transmission(self):
        """
        远程数据传输
        :return:
        """
        logger.error("远程数据传输ing：：：：：：：：")
        remote_dict["user_no"] = self.param_data["user_no"]
        remote_dict["construction_no"] = self.param_data["construction_no"]
        remote_dict["product_no"] = self.param_data["product_no"]
        remote_dict["code"] = remote_code
        remote_dict["message"] = remote_message
        remote_dict["data"] = {"num": test_num, "dataList": data_list, "preList": pre_list,
                               "displacementList": displacement_list}
        remote_dict["oil_cylinder_type"] = self.param_data["oil_cylinder_type"]
        if int(self.param_data["oil_cylinder_type"]) == 1:
            remote_dict["test_type"] = int(self.param_data["test_type"])
            remote_dict["oilcylinder_length"] = self.param_data["oilcylinder_length"]
        logger.info("远程数据参数{}：：：：：：：：".format(remote_dict))
        remote = Remote(json.dumps(remote_dict))
        remote.transmit_data()

    def stop_operate(self):
        """
        急停情况操作
        :return:
        """
        global code, message, remote_code, remote_message, is_test
        self.stop_init()
        code = remote_code = 2
        message = remote_message = "停止实验"
        is_test = 0
        self.data_transmission()

    def error_operate(self, error_code, error_message):
        """
        错误情况操作
        :param error_code: 错误代码
        :param error_message: 错误信息
        :return:
        """
        global code, message, is_test, remote_code, remote_message
        if not is_test:
            self.stop_operate()
            return
        self.stop_init()
        remote_code = error_code
        remote_message = error_message
        if self.init_check():
            message = remote_message + "请手动泄压"
        else:
            message = remote_message
        code = remote_code
        is_test = 0
        self.data_transmission()

    def oil_cylinder_extend(self, is_extend):
        """
        油缸伸出
        :param is_extend: 0停止1伸出
        :return:
        """
        if is_extend:
            Communication.action(2, 1, self.pyro_object)  # 上腔锁打开
            time.sleep(0.5)
            Communication.action(1, 1, self.pyro_object)  # 下腔进液
            Communication.action(4, 1, self.pyro_object)  # 充液
        else:
            Communication.action(1, 0, self.pyro_object)  # 下腔停液
            Communication.action(2, 0, self.pyro_object)  # 上腔锁关闭
            Communication.action(4, 0, self.pyro_object)  # 充液停止

    def oil_cylinder_recover(self, is_recover):
        """
        油缸收回
        :param is_recover:
        :return:
        """
        if is_recover:
            Communication.action(3, 1, self.pyro_object)  # 下腔锁打开
            time.sleep(0.5)
            Communication.action(0, 1, self.pyro_object)  # 上腔给液
            Communication.action(4, 1, self.pyro_object)  # 充液
        else:
            Communication.action(0, 0, self.pyro_object)  # 上腔停液
            Communication.action(3, 0, self.pyro_object)  # 下腔锁关闭
            Communication.action(4, 0, self.pyro_object)  # 充液关闭

    @classmethod
    def table_result_check(cls):
        global remote_code, remote_message
        displacement_bool_list = []
        pre_bool_list = []
        remote_code = 1
        remote_message = "试验成功"
        if displacement_list:
            displacement_bool_list = [i["boolValue"] for i in displacement_list]
            if False in displacement_bool_list:
                remote_code = 9
                remote_message = "位移偏差异常"
        if pre_list:
            pre_bool_list = [i["boolValue"] for i in pre_list]
            if False in pre_bool_list:
                remote_code = 10
                remote_message = "保压异常"
        if False in displacement_bool_list and False in pre_bool_list:
            remote_code = 11
            remote_message = "位移偏差及保压异常"

    def pressurization_protection(self, mode):
        """
        保压保护
        :param mode: 0上腔压 1下腔压
        :return:
        """
        if mode == 1:
            Communication.action(3, 1, self.pyro_object)
        else:
            Communication.action(2, 1, self.pyro_object)
        for i in range(3):
            time.sleep(2)
            if mode == 0:
                pression = self.data_convert(0, Communication.data(1, 1, self.pyro_object))
            else:
                pression = self.data_convert(0, Communication.data(1, 2, self.pyro_object))
            if pression < 10:
                return False
        return True

    def displacement_test(self):
        """
        有位移传感器测试逻辑
        :return:
        """
        logger.info("有位移测试逻辑进入：：：：：：：：")
        global code, message, is_test, remote_code, remote_message, oil_length
        self.pyro_object = Pyro5.api.Proxy(pyro5_ip)
        # 千斤顶收回
        self.oil_cylinder_recover(1)
        if self.displace_time(-10, 10):
            self.error_operate(3, "初始化超时")
            return
        # 收回停止
        self.oil_cylinder_recover(0)
        time.sleep(1)
        # 控制千斤顶伸出
        self.oil_cylinder_extend(1)
        if stretched_num > 0:
            # 判断位移减速
            if self.displace_time(oil_length / 8, (oil_length / 4) + 30):
                self.error_operate(4, "伸出超时")
                return
            Communication.action(8, 1, self.pyro_object)  # 减速
            # 在1/4位移处进行第二次位移判断
            if self.displace_time((oil_length / 4) - 20, (oil_length / 4) + 30):
                self.error_operate(4, "伸出超时")
                return
            # 伸出停止t1秒
            self.oil_cylinder_extend(0)
            Communication.action(8, 0, self.pyro_object)  # 减速停止
            # 得到第一次位移峰谷差（1/4）
            h1 = self.displace_law(journey_time)
            if h1 == "stop":
                self.stop_operate()
                return
            displacement_dict["measured_value"] = round(float(oil_length / 4), 2)
            displacement_list[-1]["measureValue"] = round(float(oil_length / 4), 2)
            # 控制千斤顶伸出
            self.oil_cylinder_extend(1)
        if stretched_num > 1:
            # 判断位移减速
            if self.displace_time((3 * oil_length) / 8, (oil_length / 2) + 30):
                self.error_operate(4, "伸出超时")
                return
            Communication.action(8, 1, self.pyro_object)  # 减速
            # 在1/2处第三次位移判断
            if self.displace_time((oil_length / 2) - 20, (oil_length / 2) + 30):
                self.error_operate(4, "伸出超时")
                return
            # 伸出停止t1
            self.oil_cylinder_extend(0)
            Communication.action(8, 0, self.pyro_object)  # 减速停止
            # 得到第二次位移峰谷差（1/2）
            h2 = self.displace_law(journey_time)
            if h2 == "stop":
                self.stop_operate()
                return
            displacement_dict["measured_value"] = round(float(oil_length / 2), 2)
            displacement_list[-1]["measureValue"] = round(float(oil_length / 2), 2)
            # 控制千斤顶伸出
            self.oil_cylinder_extend(1)
        if stretched_num > 2:
            if self.displace_time((5 * oil_length) / 8, (3 * oil_length) / 4 + 30):
                self.error_operate(4, "伸出超时")
                return
            Communication.action(8, 1, self.pyro_object)  # 减速
            # 在3/4处第四次位移判断
            if self.displace_time((3 * oil_length) / 4 - 20, (3 * oil_length) / 4 + 30):
                self.error_operate(4, "伸出超时")
                return
            # 伸出停止t1
            self.oil_cylinder_extend(0)
            Communication.action(8, 0, self.pyro_object)  # 减速停止
            # 得到第三次位移峰谷差（3/4）
            h3 = self.displace_law(journey_time)
            if h3 == "stop":
                self.stop_operate()
                return
            displacement_dict["measured_value"] = round(float((3 * oil_length) / 4), 2)
            displacement_list[-1]["measureValue"] = round(float((3 * oil_length) / 4), 2)
            # 控制千斤顶伸出
            self.oil_cylinder_extend(1)
        # 在3/4处第四次位移判断
        if self.displace_time(oil_length - 10, oil_length + 10):
            self.error_operate(4, "伸出超时")
            return
        Communication.action(8, 1, self.pyro_object)  # 减速
        # 判断下腔压力是否大于40Mpa
        pressure_return = self.pression_time(pressure_keep, 1)
        if pressure_return:
            if pressure_return == "error":
                self.error_operate(15, "压力超过最大值")
            else:
                self.error_operate(5, "增压超时")
            return
        # if self.pression_time(pressure_keep, 1):
        #     self.error_operate(5, "增压超时")
        #     return

        # 伸出停止t2
        self.oil_cylinder_extend(0)
        Communication.action(6, 0, self.pyro_object)  # 加压1停止
        Communication.action(7, 0, self.pyro_object)  # 加压2停止
        Communication.action(8, 0, self.pyro_object)  # 减速停止
        # 卸载系统压
        Communication.action(5, 1, self.pyro_object)  # 卸载
        time.sleep(1)
        Communication.action(5, 0, self.pyro_object)
        # 计算第一次下腔压力峰谷差
        q1 = self.pression_law(pressure_time, 1, str3)
        if q1 == "stop":
            self.stop_operate()
            return ""
        displacement_dict["measured_value"] = round(float(oil_length), 2)
        displacement_list[-1]["measureValue"] = round(float(oil_length), 2)
        if self.pressurization_protection(1):
            self.error_operate(14, "高压未卸载")
            return ""
        if pressure_middle == 1:
            # 控制千斤顶收回
            self.oil_cylinder_recover(1)
            if self.displace_time(((2 * oil_length) / 3) - 30, (7 * oil_length) / 8):
                self.error_operate(6, "收回超时")
                return
            Communication.action(8, 1, self.pyro_object)  # 减速开启
            # 收回阶段第一次位移判断
            if self.displace_time(((2 * oil_length) / 3) - 30, ((2 * oil_length) / 3) + 30):
                self.error_operate(6, "收回超时")
                return
            # 关闭千斤顶下腔锁
            Communication.action(3, 0, self.pyro_object)  # 下腔锁关闭
            # 判断上腔压力是否大于40Mpa
            pressure_return = self.pression_time(pressure_keep, 0)
            if pressure_return:
                if pressure_return == "error":
                    self.error_operate(15, "压力超过最大值")
                else:
                    self.error_operate(5, "增压超时")
                return
            # if self.pression_time(pressure_keep, 0):
            #     self.error_operate(5, "增压超时")
            #     return
            # 伸出停止t2
            Communication.action(6, 0, self.pyro_object)  # 加压1停止
            Communication.action(7, 0, self.pyro_object)  # 加压2停止
            Communication.action(8, 0, self.pyro_object)  # 减速停止
            Communication.action(0, 0, self.pyro_object)  # 上腔停液
            Communication.action(4, 0, self.pyro_object)  # 充液停止
            # 卸载系统压
            Communication.action(5, 1, self.pyro_object)  # 卸载
            time.sleep(1)
            Communication.action(5, 0, self.pyro_object)

            # 计算第二次压力差
            q2 = self.pression_law(pressure_time, 0, str2)
            if q2 == "stop":
                self.stop_operate()
                return
            if self.pressurization_protection(1):
                self.error_operate(14, "高压未卸载")
                return ""
        # 控制千斤顶收回
        self.oil_cylinder_recover(1)
        # 判断位移是否回到起点位置
        if self.displace_time(-10, 10):
            self.error_operate(6, "收回超时")
            return
        Communication.action(8, 1, self.pyro_object)  # 减速打开
        # 判断上腔压力是否大于40Mpa
        pressure_return = self.pression_time(pressure_keep, 0)
        if pressure_return:
            if pressure_return == "error":
                self.error_operate(15, "压力超过最大值")
            else:
                self.error_operate(5, "增压超时")
            return

        # if self.pression_time(pressure_keep, 0):
        #     self.error_operate(5, "增压超时")
        #     return
        # 伸出停止t2
        self.oil_cylinder_recover(0)
        Communication.action(6, 0, self.pyro_object)  # 加压1停止
        Communication.action(7, 0, self.pyro_object)  # 加压2停止
        Communication.action(8, 0, self.pyro_object)  # 减速停止
        # 判断上腔压大于40 卸载系统压
        Communication.action(5, 1, self.pyro_object)  # 卸载
        time.sleep(1)
        Communication.action(5, 0, self.pyro_object)
        # 计算机第三次压力峰谷差
        q3 = self.pression_law(pressure_time, 0, str1)
        if q3 == "stop":
            self.stop_operate()
            return
        displacement_dict["measured_value"] = round(float(0), 2)
        displacement_list[-1]["measureValue"] = round(float(0), 2)
        self.stop_init()
        self.table_result_check()
        if self.init_check():
            code = 12
            message = remote_message + "请手动泄压"
        else:
            code = 1
            message = remote_message
        is_test = 0
        oil_length = 0
        self.data_transmission()

    def no_displacement_pression_judge(self, mode):
        """
        无位移，增压超时
        mode: 0 上腔，1 下腔
        """
        Communication.action(8, 1, self.pyro_object)  # 减速打开
        # 判断下腔压力是否大于40Mpa
        pressure_return = self.pression_time(pressure_keep, mode)
        if pressure_return:
            if pressure_return == "error":
                self.error_operate(15, "压力超过最大值")
            else:
                self.error_operate(5, "增压超时")
            return True
        # 伸出停止
        self.oil_cylinder_extend(0)
        Communication.action(6, 0, self.pyro_object)  # 加压1停止
        Communication.action(7, 0, self.pyro_object)  # 加压2停止
        Communication.action(8, 0, self.pyro_object)  # 减速停止
        return False

    def no_displacement_test(self):
        """
        无位移测试逻辑
        :return:
        """
        logger.info("无位移测试逻辑进入：：：：：：：：")
        global code, message, is_test, remote_code, remote_message, oil_length
        # 伸出
        self.pyro_object = Pyro5.api.Proxy(pyro5_ip)
        self.oil_cylinder_extend(1)
        time.sleep(2)
        # 下强压 系统压 临界值
        if self.no_displacement_judge(1):
            self.error_operate(4, "伸出超时")
            return
        # 停止伸出
        self.oil_cylinder_extend(0)
        # 收回
        self.oil_cylinder_recover(1)
        time.sleep(2)
        if self.no_displacement_judge(0):
            self.error_operate(6, "收回超时")
            return
        # 停止收回
        self.oil_cylinder_recover(0)
        time.sleep(1)
        # 伸出
        self.oil_cylinder_extend(1)
        time.sleep(2)
        if self.no_displacement_judge(1):
            self.error_operate(4, "伸出超时")
            return
        # 减速 上腔压 判断
        if self.no_displacement_pression_judge(1):
            return
        #卸载系统压
        Communication.action(5, 1, self.pyro_object)
        time.sleep(1)
        Communication.action(5, 0, self.pyro_object)
        #保压
        q1 = self.pression_law(pressure_time, 1, str3)
        if q1 == "stop":
            self.stop_operate()
            return
        if self.pressurization_protection(1):
            self.error_operate(14, "高压未卸载")
            return ""
        # 控制千斤顶收回
        self.oil_cylinder_recover(1)
        time.sleep(2)
        if self.no_displacement_judge(0):
            self.error_operate(6, "收回超时")
            return
        # 减速 下腔压 判断
        if self.no_displacement_pression_judge(0):
            return
        #卸载系统压
        Communication.action(5, 1, self.pyro_object)  # 卸载
        time.sleep(1)
        Communication.action(5, 0, self.pyro_object)
        #保压
        q3 = self.pression_law(pressure_time, 0, str1)
        if q3 == "stop":
            self.stop_operate()
            return
        self.stop_init()
        self.table_result_check()
        if self.init_check():
            code = 12
            message = remote_message + "请手动泄压"
        else:
            code = 1
            message = remote_message
        is_test = 0
        oil_length = 0
        self.data_transmission()

    # 开始实验，初始化
    def oil_start_init(self):
        """
        开始实验，初始化
        :return:
        """
        logger.info("初始化参数：：：：：：：：")
        global test_type, displacement_exist, oil_length, is_test, fast_pressurize_time_interval, \
            slow_pressurize_time_interval, test_num, num, oil_cylinder_type
        oil_cylinder_type = int(self.param_data["oil_cylinder_type"])
        if oil_cylinder_type > 5:
            fast_pressurize_time_interval = oil_size["oil_small"]["fast_interval"]
            slow_pressurize_time_interval = oil_size["oil_small"]["slow_interval"]
        else:
            fast_pressurize_time_interval = oil_size["oil_large"]["fast_interval"]
            slow_pressurize_time_interval = oil_size["oil_large"]["slow_interval"]
        # 是否有位移，是否有电流
        if oil_cylinder_type == 1:
            # test_type 1 压力 2电流
            displacement_exist = 1
            oil_length = int(self.param_data["oilcylinder_length"])
            test_type = int(self.param_data["test_type"])
        else:
            # 无位移
            displacement_exist = 0
            test_type = 1
        test_num = str(time.time())
        is_test = 1
        num = 0
        displacement_dict.clear()
        pre_dict.clear()
        displacement_list.clear()
        pre_list.clear()
        data_list.clear()
        queue_dict.clear()
        data_dict.clear()
        remote_dict.clear()
        logger.info("初始化参数完成：：：：：：：：")
        logger.info("油缸类型{}：：：：：：：：".format(oil_cylinder_type))

    @classmethod
    def return_message(cls, exception_code, exception_message, status):
        """
        返回报文
        :param exception_code: 异常code
        :param exception_message: 异常信息
        :param status: 返回状态
        :return:
        """
        return json.dumps({"code": exception_code, "message": exception_message, "success": status})

    def no_displacement_start(self):
        logger.info("无位移实验接口调用：：：：：：：：")
        Thread(target=self.no_displacement_start_thread).start()
        return True

    def no_displacement_start_thread(self):
        """
        无位移
        :return:
        """
        global is_test
        self.oil_start_init()
        try:
            self.no_displacement_test()
        except ConnectionFailException as e:
            is_test = 0
            q.put(self.return_message(13, str(e), False))
            logger.error("连接异常：：：：：：：：")
        else:
            self.return_message(None, None, True)

    def start(self):
        logger.info("有位移电压实验接口调用：：：：：：：：")
        Thread(target=self.start_thread).start()
        return True

    def start_thread(self):
        """
        电压型 有行程油缸
        :return:
        """
        global is_test
        self.oil_start_init()
        try:
            self.displacement_test()
        except ConnectionFailException as e:
            is_test = 0
            q.put(self.return_message(13, str(e), False))
            logger.error("连接异常：：：：：：：：")
        else:
            self.return_message(None, None, True)

    def electricity_start(self):
        logger.info("有位移电流实验接口调用：：：：：：：：")
        Thread(target=self.electricity_start_thread).start()
        return True

    def electricity_start_thread(self):
        """
        电流型 有行程油缸
        :return:
        """
        global is_test
        self.oil_start_init()
        try:
            self.displacement_test()
        except ConnectionFailException as e:
            is_test = 0
            q.put(self.return_message(13, str(e), False))
            logger.error("连接异常：：：：：：：：")
        else:
            return self.return_message(None, None, True)

    @classmethod
    def set_queue(cls):
        try:
            cls.set_queue_job()
        except ConnectionFailException as e:
            q.put(cls.return_message(13, str(e), False))
            logger.error("连接异常：：：：：：：：")

    @classmethod
    def set_queue_job(cls):
        """
        通信数据放入队列任务
        :return:
        """
        global num, code, message, is_test
        pyro = Pyro5.api.Proxy(pyro5_ip)
        if float(Communication.data(1, 0, pyro)) >= 0.5:
            displacement_data = cls.data_convert(1, Communication.data(1, 0, pyro))
        else:
            displacement_data = 0
        if not is_test:
            num = 0
        else:
            if not displacement_exist:
                displacement_data = 0
            else:
                if test_type == 1:
                    displacement_data = cls.data_convert(1, Communication.data(1, 0, pyro))
                else:
                    displacement_data = cls.data_convert(2, Communication.data(2, 0, pyro))
        if int(Communication.switching_value(1, pyro)) or int(Communication.switching_value(0, pyro)):
            is_test = 0
        if oil_cylinder_type != 1:
            displacement_dict.clear()
            displacement_list.clear()
        queue_dict["isTest"] = is_test
        queue_dict["code"] = code
        queue_dict["message"] = message
        queue_dict["status"] = Communication.switching_value(1, pyro)
        queue_dict["urgent_stop"] = Communication.switching_value(0, pyro)
        data_dict["displacementDict"] = displacement_dict
        data_dict["preDict"] = pre_dict
        data_dict["dataList"] = {'realLength': round(displacement_data, 2),
                                 'upPre': round(cls.data_convert(0, Communication.data(1, 1, pyro)), 2),
                                 'downPre': round(cls.data_convert(0, Communication.data(1, 2, pyro)), 2),
                                 'systemPre': round(cls.data_convert(0, Communication.data(1, 3, pyro)), 2),
                                 'pumpPre': round(cls.data_convert(0, Communication.data(1, 4, pyro)), 2),
                                 'currentTime': num}
        queue_dict["testNo"] = test_num
        queue_dict["data"] = data_dict
        q.put(json.dumps(queue_dict))
        if displacement_dict:
            displacement_dict.clear()
        if pre_dict:
            pre_dict.clear()
        if code is not None:
            logger.info("实验结果信息为code={}，message={}".format(code, message))
            code = None
            message = None
        if is_test:
            data_list.append(
                {'realLength': displacement_data, 'upPre': cls.data_convert(0, Communication.data(1, 1, pyro)),
                 'downPre': cls.data_convert(0, Communication.data(1, 2, pyro)), 'currentTime': num})
        num += 1.5