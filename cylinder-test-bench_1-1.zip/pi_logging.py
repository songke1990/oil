import logging
import logging.handlers

logging.basicConfig()

logger = logging.getLogger('moxa_log')
logger.setLevel(logging.INFO)
file_handler = logging.handlers.TimedRotatingFileHandler("./logs/moxa_log.log", encoding='utf-8', when='D', interval=1,
                                                         backupCount=6)
formatter = logging.Formatter('%(asctime)s %(filename)s-%(lineno)d %(levelname)s: %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

logger.info("123")
