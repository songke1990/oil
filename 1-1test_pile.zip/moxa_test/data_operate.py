import csv
import json

data_list = []
with open("figuredata.csv") as f:
    f_csv = csv.reader(f)
    n = 0
    for row in f_csv:
        data_list.append([float(row[0]) / 225 + 0.5, float(row[1]) / 15 + 0.5, float(row[2]) / 15 + 0.5])
        n += 1

with open("test_data.json", "w") as f:
    json.dump(data_list, f)
